#!/usr/bin/env python3
"""Cho phép chạy `python -m adgr.cli ...` từ thư mục repo."""
from adgr.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
