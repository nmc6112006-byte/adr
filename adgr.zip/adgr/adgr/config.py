"""Cấu hình ADGR: load YAML + ghi đè bằng biến môi trường ADGR_* và CLI."""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List

import yaml

CONFIG_KEYS_WITH_DOTS = True  # hỗ trợ key lồng nhau dạng "retrieval.k"


@dataclass
class LLMConfig:
    model: str = "Qwen/Qwen2.5-14B-Instruct-AWQ"
    base_url: str = "http://localhost:8000/v1"
    api_key: str = "EMPTY"
    temperature: float = 0.0
    top_p: float = 1.0
    max_tokens: int = 4096
    request_timeout: int = 240
    vllm_gpu_memory_utilization: float = 0.85
    vllm_max_model_len: int = 8192


@dataclass
class EmbedConfig:
    model: str = "intfloat/multilingual-e5-small"
    device: str = "cpu"
    batch_size: int = 64
    query_prefix: str = "query: "
    passage_prefix: str = "passage: "


@dataclass
class RerankConfig:
    model: str = "BAAI/bge-reranker-v2-m3"
    device: str = "cpu"
    batch_size: int = 16
    max_length: int = 1024


@dataclass
class CorpusConfig:
    source: str = "sample"
    hf_dataset: str = "vuduylinh150804/vietmed-crawled-corpus"
    hf_limit: int = 300
    upload_dir: str = "uploads"
    max_chunk_chars: int = 1000
    min_chunk_chars: int = 120


@dataclass
class KGConfig:
    entity_types: List[str] = field(default_factory=lambda: [
        "Disease", "Symptom", "Drug", "Chemical compound", "Protein",
        "Anatomy", "Biological process", "Exposure", "Diagnostic test",
        "Treatment method", "Other",
    ])
    max_chunks_per_run: int = 0
    max_entities_per_chunk: int = 20
    max_relations_per_chunk: int = 20


@dataclass
class RetrievalConfig:
    d: int = 10
    tau_anchor: float = 0.6
    delta: float = 0.1
    k: int = 15
    alpha: float = 0.3
    beta: float = 0.7
    tau_edge: float = 0.3
    m: int = 10
    n_max: int = 50
    n_g: int = 15
    n_s: int = 10
    r: int = 5
    n_c: int = 10
    max_context_tokens: int = 30000


@dataclass
class GenerationConfig:
    temperature: float = 0.0
    max_tokens: int = 1024
    system_prompt: str = (
        "Bạn là trợ lý y tế tiếng Việt. Chỉ trả lời dựa trên NGỮ CẢNH được cung cấp. "
        "Nếu ngữ cảnh không đủ thông tin, hãy nói rõ bạn không tìm thấy thông tin "
        "trong tài liệu. Trả lời ngắn gọn, chính xác, có cấu trúc, không bịa thêm "
        "thông tin y tế."
    )


@dataclass
class EvalConfig:
    ks: List[int] = field(default_factory=lambda: [1, 3, 5, 10])
    mrr_k: int = 10
    judge_runs: int = 1
    eval_limit: int = 0


@dataclass
class ADGRConfig:
    llm_backend: str = "mock"
    embed_backend: str = "hash_mock"
    rerank_backend: str = "none"
    llm: LLMConfig = field(default_factory=LLMConfig)
    embed: EmbedConfig = field(default_factory=EmbedConfig)
    rerank: RerankConfig = field(default_factory=RerankConfig)
    corpus: CorpusConfig = field(default_factory=CorpusConfig)
    kg: KGConfig = field(default_factory=KGConfig)
    retrieval: RetrievalConfig = field(default_factory=RetrievalConfig)
    generation: GenerationConfig = field(default_factory=GenerationConfig)
    eval: EvalConfig = field(default_factory=EvalConfig)
    verbose: bool = True
    seed: int = 13

    # ----------------- IO -----------------
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def save(self, path: Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            yaml.safe_dump(self.to_dict(), f, allow_unicode=True, sort_keys=False)

    @staticmethod
    def load(path: str | Path | None = None, overrides: Dict[str, Any] | None = None) -> "ADGRConfig":
        data: Dict[str, Any] = {}
        if path is not None and Path(path).exists():
            with open(path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
        cfg = _from_dict(data)
        _apply_env(cfg)
        if overrides:
            for key, value in overrides.items():
                _set_nested(cfg, key, value)
        return cfg


# ----------------- helpers -----------------
def _from_dict(data: Dict[str, Any]) -> ADGRConfig:
    cfg = ADGRConfig()
    simple = ("llm_backend", "embed_backend", "rerank_backend", "verbose", "seed")
    for key in simple:
        if key in data:
            setattr(cfg, key, data[key])
    for section, cls in [
        ("llm", LLMConfig), ("embed", EmbedConfig), ("rerank", RerankConfig),
        ("corpus", CorpusConfig), ("kg", KGConfig), ("retrieval", RetrievalConfig),
        ("generation", GenerationConfig), ("eval", EvalConfig),
    ]:
        if section in data and isinstance(data[section], dict):
            valid = {f for f in cls.__dataclass_fields__}
            filtered = {k: v for k, v in data[section].items() if k in valid}
            setattr(cfg, section, cls(**filtered))
    return cfg


def _apply_env(cfg: ADGRConfig) -> None:
    """Ghi đè cấu hình bằng biến môi trường ADGR_XXX.

    Ví dụ:
      ADGR_LLM_BACKEND=openai_compat
      ADGR_LLM_BASE_URL=http://localhost:8000/v1
      ADGR_RETRIEVAL_K=20
      ADGR_EMBED_MODEL=google/embeddinggemma-300m
    """
    prefix = "ADGR_"
    for raw_key, raw_val in os.environ.items():
        if not raw_key.startswith(prefix) or raw_key in (prefix + "DATA_DIR",):
            continue
        key_path = raw_key[len(prefix):].lower().split("_")
        # map tên biến về đường dẫn cấu hình
        sections = {"llm": "llm", "embed": "embed", "rerank": "rerank",
                    "corpus": "corpus", "kg": "kg", "retrieval": "retrieval",
                    "generation": "generation", "eval": "eval"}
        if key_path[0] in sections and len(key_path) >= 2:
            section = sections[key_path[0]]
            attr = "_".join(key_path[1:])
            target: Any = getattr(cfg, section)
            if hasattr(target, attr):
                cur = getattr(target, attr)
                setattr(target, attr, _coerce(raw_val, cur))
        else:
            # biến cấp cao: ADGR_LLM_BACKEND / ADGR_EMBED_BACKEND / ADGR_RERANK_BACKEND
            name = "_".join(key_path)
            if hasattr(cfg, name):
                setattr(cfg, name, _coerce(raw_val, getattr(cfg, name)))


def _coerce(val: str, ref: Any) -> Any:
    if isinstance(ref, bool):
        return val.lower() in ("1", "true", "yes", "on")
    if isinstance(ref, int) and not isinstance(ref, bool):
        try:
            return int(val)
        except ValueError:
            return val
    if isinstance(ref, float):
        try:
            return float(val)
        except ValueError:
            return val
    if isinstance(ref, list):
        try:
            return json.loads(val)
        except Exception:
            return [x.strip() for x in val.split(",") if x.strip()]
    return val


def _set_nested(obj: Any, dotted: str, value: Any) -> None:
    parts = dotted.split(".")
    target = obj
    for p in parts[:-1]:
        if not hasattr(target, p):
            raise KeyError(f"Khong ton tai khoa cau hinh: {dotted}")
        target = getattr(target, p)
    last = parts[-1]
    if not hasattr(target, last):
        raise KeyError(f"Khong ton tai khoa cau hinh: {dotted}")
    cur = getattr(target, last)
    setattr(target, last, _coerce(str(value), cur) if not isinstance(value, str) else _coerce(value, cur))
