// zai_bridge.mjs - cầu nối Python -> z-ai-web-dev-sdk
// Đọc JSON từ stdin: {messages, temperature, max_tokens}
// Ghi JSON ra stdout: {ok: true, content} | {ok: false, error}
import fs from "node:fs";

const raw = fs.readFileSync(0, "utf-8");
let req;
try {
  req = JSON.parse(raw);
} catch (e) {
  process.stdout.write(JSON.stringify({ ok: false, error: "bad json: " + e.message }));
  process.exit(0);
}

try {
  const { default: ZAI } = await import("z-ai-web-dev-sdk");
  const zai = await ZAI.create();
  const completion = await zai.chat.completions.create({
    messages: req.messages,
    temperature: req.temperature ?? 0.0,
    max_tokens: req.max_tokens ?? 2048,
  });
  const content = completion?.choices?.[0]?.message?.content ?? "";
  process.stdout.write(JSON.stringify({ ok: true, content }));
} catch (e) {
  process.stdout.write(JSON.stringify({ ok: false, error: String(e?.message || e) }));
}
process.exit(0);
