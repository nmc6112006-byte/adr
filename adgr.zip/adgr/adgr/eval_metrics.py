"""Retrieval metrics: Hit@K, MRR@K, nDCG@K (giống Section 5.3 paper)."""
from __future__ import annotations

import math
from typing import Dict, List


def hit_at_k(ranked: List[str], gold: str, k: int) -> float:
    return 1.0 if gold in ranked[:k] else 0.0


def mrr_at_k(ranked: List[str], gold: str, k: int) -> float:
    for i, cid in enumerate(ranked[:k], 1):
        if cid == gold:
            return 1.0 / i
    return 0.0


def ndcg_at_k(ranked: List[str], gold: str, k: int) -> float:
    """1 item relevant: nDCG = 1/log2(rank+1) nếu gold trong top-k."""
    for i, cid in enumerate(ranked[:k], 1):
        if cid == gold:
            return 1.0 / math.log2(i + 1)
    return 0.0


def summarize_runs(runs: List[Dict], ks: List[int], mrr_k: int = 10) -> Dict:
    """runs: list item có 'ranked_chunks' (list chunk_id theo thứ tự) và 'gold_chunk'."""
    out: Dict[str, float] = {}
    n = max(1, len(runs))
    for k in ks:
        out[f"Hit@{k}"] = sum(hit_at_k(r["ranked_chunks"], r["gold_chunk"], k)
                              for r in runs) / n
        out[f"nDCG@{k}"] = sum(ndcg_at_k(r["ranked_chunks"], r["gold_chunk"], k)
                               for r in runs) / n
    out[f"MRR@{mrr_k}"] = sum(mrr_at_k(r["ranked_chunks"], r["gold_chunk"], mrr_k)
                              for r in runs) / n
    return {key: round(val, 4) for key, val in out.items()}
