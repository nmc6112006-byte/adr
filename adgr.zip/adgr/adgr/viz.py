"""Visualization: xuất HTML tương tác cho (1) đồ thị KG và (2) retrieval trace.

- KG: vis-network, node tô màu theo 11 loại thực thể, kích thước theo bậc;
  filter theo loại/degree; tìm kiếm entity; click xem mô tả + source chunks.
- Trace: hiển thị đường đi evidence của 1 truy vấn — Kl/Kh -> anchors (viền cam)
  -> edges được chọn -> 4 nguồn evidence (Tv/Te/Tg/Ts) -> context cuối.
Cả hai là file HTML standalone (CDN vis-network), mở bằng trình duyệt bất kỳ.
"""
from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Dict, List, Optional

from .kg_schema import TYPE_COLORS
from .store import AdgrStore
from .retrieval import RetrievalTrace
from .utils import ensure_dir, write_json

VISNET_CDN = "https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"


# ----------------------------------------------------------------------
def export_kg_html(store: AdgrStore, out_path: Path,
                   top_n: int = 400, min_degree: int = 1) -> Path:
    """Xuất đồ thị KG (giới hạn top_n node bậc cao nhất để dễ xem)."""
    kg = store.kg
    deg = {eid: len(kg.adj.get(eid, ())) for eid in kg.entities}
    picked = [eid for eid, dv in sorted(deg.items(), key=lambda x: -x[1])[:top_n]
              if dv >= min_degree] or list(kg.entities)[:top_n]
    picked_set = set(picked)

    nodes = []
    for eid in picked:
        e = kg.entities[eid]
        nodes.append({
            "id": eid, "label": e.name, "title": html.escape(
                f"[{e.type}] {e.description[:300]}"),
            "group": e.type,
            "value": max(1, deg.get(eid, 1)),
        })
    edges = []
    seen = set()
    for rid, r in kg.relations.items():
        if r.source_id in picked_set and r.target_id in picked_set:
            key = tuple(sorted((r.source_id, r.target_id)))
            if key in seen:
                continue
            seen.add(key)
            s, t = kg.endpoints(r)
            edges.append({
                "from": r.source_id, "to": r.target_id,
                "label": html.escape(r.keywords[:32]),
                "title": html.escape(f"{s.name} -[{r.keywords}]-> {t.name}\n{r.description[:200]}"),
                "font": {"size": 9},
            })

    legend = [{"type": t, "color": c} for t, c in TYPE_COLORS.items()]
    data_json = json.dumps({"nodes": nodes, "edges": edges, "legend": legend},
                           ensure_ascii=False)

    html_doc = _HTML_TMPL.replace("__TITLE__", "ViMedGraph - Knowledge Graph (ADGR)")
    html_doc = html_doc.replace("__DATA__", data_json)
    html_doc = html_doc.replace("__MODE__", "kg")
    out_path = ensure_dir(out_path.parent) / out_path.name
    out_path.write_text(html_doc, encoding="utf-8")
    return out_path


# ----------------------------------------------------------------------
def export_trace_html(store: AdgrStore, trace: RetrievalTrace, out_path: Path) -> Path:
    """Xuất HTML hiển thị từng bước retrieval của 1 truy vấn."""
    kg = store.kg
    anchor_ids = {a.entity_id for a in trace.anchors}

    nodes, edges = [], []
    edge_ids = {e.relation_id for e in trace.edges}
    glob_ids = {g["relation_id"] for g in trace.global_edges}

    for a in trace.anchors:
        e = kg.entities[a.entity_id]
        nodes.append({
            "id": a.entity_id, "label": a.name,
            "group": e.type, "value": 4,
            "shapeProperties": {"borderDashes": False},
            "title": html.escape(f"ANCHOR score={a.score:.3f} cos={a.cos:.3f} "
                                 f"BM25={'✓' if a.via_bm25 else '✗'} "
                                 f"dense={'✓' if a.via_dense else '✗'} "
                                 f"overlap={'✓' if a.overlap else '✗'}\n{e.description[:200]}"),
            "borderWidth": 4, "color": {"border": "#ff9800"},
        })
    # endpoint của edges + global
    for rid in list(edge_ids) + list(glob_ids):
        r = kg.relations.get(rid)
        if not r:
            continue
        for eid in (r.source_id, r.target_id):
            ent = kg.entities[eid]
            is_anchor = eid in anchor_ids
            nodes.append({
                "id": eid, "label": ent.name, "group": ent.type, "value": 2 if not is_anchor else 4,
                "title": html.escape(f"[{ent.type}] {ent.description[:200]}"),
                "borderWidth": 4 if is_anchor else 1,
                "color": {"border": "#ff9800"} if is_anchor else {},
            })
    for e in trace.edges:
        r = kg.relations[e.relation_id]
        edges.append({
            "from": r.source_id, "to": r.target_id,
            "label": html.escape(f"{e.keywords[:24]} ({e.s_edge:.2f})"),
            "title": html.escape(f"s_sem={e.s_sem:.3f} s_edge={e.s_edge:.3f}\n{r.description[:200]}"),
            "color": {"color": "#2e7d32", "highlight": "#1b5e20"}, "width": 2,
            "font": {"size": 9},
        })
    for g in trace.global_edges:
        r = kg.relations.get(g["relation_id"])
        if not r:
            continue
        edges.append({
            "from": r.source_id, "to": r.target_id,
            "label": html.escape(f"global {g['s_sem']:.2f}"),
            "color": {"color": "#1565c0"}, "dashes": True,
            "font": {"size": 9},
        })

    # danh sách chunk theo 4 nguồn
    def chunk_rows(cids: List[str], with_score: bool = False) -> str:
        rows = []
        for cid in (cids or [])[:20]:
            ch = store.chunk_by_id.get(cid)
            if not ch:
                continue
            rows.append(f"<li><b>{html.escape(ch.doc_title)}</b> "
                        f"<span class='sec'>§ {' > '.join(ch.section_path[:2])}</span>"
                        f"<div class='txt'>{html.escape(ch.content[:260])}…</div></li>")
        return "<ul class='chunks'>" + "".join(rows) + "</ul>" if rows else "<i>(trống)</i>"

    kw = trace.keywords
    anchors_tbl = "".join(
        f"<tr><td>{html.escape(a.name)}</td><td>{a.type}</td><td>{a.score:.3f}</td>"
        f"<td>{a.cos:.3f}</td><td>{'✓' if a.via_bm25 else ''}</td>"
        f"<td>{'✓' if a.via_dense else ''}</td><td>{'✓' if a.overlap else ''}</td></tr>"
        for a in trace.anchors)
    edges_tbl = "".join(
        f"<tr><td>{html.escape(e.anchor_name)}</td><td>{html.escape(e.source_name)}</td>"
        f"<td>{html.escape(e.keywords)}</td><td>{html.escape(e.target_name)}</td>"
        f"<td>{e.s_sem:.3f}</td><td>{e.s_edge:.3f}</td></tr>"
        for e in trace.edges)
    rerank_tbl = "".join(
        f"<tr><td>{i+1}</td><td>{html.escape(store.chunk_by_id[cid].doc_title if cid in store.chunk_by_id else cid)}</td>"
        f"<td>{html.escape(' > '.join(store.chunk_by_id[cid].section_path) if cid in store.chunk_by_id else '')}</td>"
        f"<td>{score:.3f}</td></tr>"
        for i, (cid, score) in enumerate(trace.reranked))

    paths = trace.paths
    html_doc = _HTML_TMPL.replace("__TITLE__", f"ADGR Retrieval Trace: {trace.query[:60]}")
    html_doc = html_doc.replace("__MODE__", "trace")
    body = f"""
<h1>ADGR Retrieval Trace</h1>
<p class="query">Truy vấn: <b>{html.escape(trace.query)}</b></p>
<div class="kpis">
  <span>Anchors: {len(trace.anchors)}</span>
  <span>Edges: {len(trace.edges)}</span>
  <span>Global: {len(trace.global_edges)}</span>
  <span>Merged: {len(trace.merged)}</span>
  <span>Final: {len(trace.final_chunks)}</span>
  <span>Thời gian: {trace.timings.get('total_ms', 0):.0f} ms</span>
</div>
<h2>Block 2 - Keywords ({kw.source if kw else '?'}, {kw.latency_ms:.0f} ms)</h2>
<p><b>Low-level (K<sub>l</sub>):</b> {html.escape(', '.join(kw.low_level))}<br>
   <b>High-level (K<sub>h</sub>):</b> {html.escape(', '.join(kw.high_level))}</p>
<h2>Block 3 - Anchors (overlap-aware hybrid)</h2>
<table><tr><th>Entity</th><th>Loại</th><th>s_anchor</th><th>cos</th><th>BM25</th><th>Dense</th><th>Overlap</th></tr>{anchors_tbl}</table>
<h2>Block 4 - Selected edges (s_edge = α·s_anchor + β·s_sem)</h2>
<table><tr><th>Anchor</th><th>Source</th><th>Relation</th><th>Target</th><th>s_sem</th><th>s_edge</th></tr>{edges_tbl}</table>
<h2>Block 5 - Evidence paths</h2>
<div class="cols">
  <div><h3>T<sub>v</sub> - từ anchors/global endpoints</h3>{chunk_rows(paths.tv if paths else [])}</div>
  <div><h3>T<sub>e</sub> - từ selected edges</h3>{chunk_rows(paths.te if paths else [])}</div>
  <div><h3>T<sub>g</sub> - từ global relations</h3>{chunk_rows(paths.tg if paths else [])}</div>
  <div><h3>T<sub>s</sub> - direct semantic</h3>{chunk_rows([c for c, _ in (paths.ts if paths else [])])}</div>
</div>
<h2>Final context sau cross-encoder rerank (Top-{len(trace.final_chunks)})</h2>
<table><tr><th>#</th><th>Tài liệu</th><th>Section</th><th>Score</th></tr>{rerank_tbl}</table>
<h2>Đồ thị retrieval</h2>
<div id="graph" style="height:640px;border:1px solid #ddd;border-radius:8px"></div>
"""
    data_json = json.dumps({"nodes": _dedup_nodes(nodes), "edges": edges}, ensure_ascii=False)
    html_doc = html_doc.replace("__DATA__", data_json)
    html_doc = html_doc.replace("__BODY__", body)
    out_path = ensure_dir(out_path.parent) / out_path.name
    out_path.write_text(html_doc, encoding="utf-8")
    return out_path


def _dedup_nodes(nodes: List[dict]) -> List[dict]:
    seen = set()
    out = []
    for n in nodes:
        if n["id"] in seen:
            continue
        seen.add(n["id"])
        out.append(n)
    return out


# ----------------------------------------------------------------------
_HTML_TMPL = """<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8">
<title>__TITLE__</title>
<script src="__CDN__"></script>
<style>
 body { font-family: 'Segoe UI', system-ui, sans-serif; margin: 24px; background:#f7f8fa; color:#1c2733; }
 h1 { font-size: 22px; } h2 { font-size: 17px; margin-top: 28px; border-left: 4px solid #ff9800; padding-left: 8px;}
 h3 { font-size: 14px; }
 .query { font-size: 15px; background:#fff3e0; padding:10px 14px; border-radius:8px; }
 .kpis span { display:inline-block; background:#fff; border:1px solid #e0e4e8; padding:6px 12px;
              border-radius:16px; margin-right:8px; font-size:13px; }
 table { border-collapse: collapse; width: 100%; font-size: 12.5px; background:#fff; }
 th, td { border: 1px solid #e3e7eb; padding: 5px 8px; text-align: left; }
 th { background: #eef2f6; }
 .cols { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
 .chunks { padding-left: 16px; } .chunks li { margin-bottom: 8px; }
 .chunks .sec { color:#667; font-size: 11px; } .chunks .txt { color:#445; font-size:12px; }
 #graph { background: #fff; }
 #controls { margin: 12px 0; }
 #controls select, #controls input { padding: 6px; margin-right: 8px; border: 1px solid #ccc; border-radius: 6px; }
 .legend span { display:inline-block; padding:3px 10px; margin:2px; border-radius: 12px; font-size:12px; color:#fff; }
</style>
</head>
<body>
__BODY__
<script>
const DATA = __DATA__;
__SCRIPT__
</script>
</body>
</html>
""".replace("__CDN__", VISNET_CDN)


# script KG mode + trace mode
def _render_script() -> str:
    return """
if (DATA.legend) {
  // ---- KG mode ----
  const legendDiv = document.createElement('div');
  legendDiv.className = 'legend';
  const types = {};
  DATA.nodes.forEach(n => types[n.group] = true);
  DATA.legend.forEach(l => {
    if (types[l.type]) {
      const s = document.createElement('span');
      s.style.background = l.color; s.textContent = l.type;
      legendDiv.appendChild(s);
    }
  });
  document.body.insertBefore(legendDiv, document.body.firstChild.nextSibling);

  const ctrl = document.createElement('div');
  ctrl.id = 'controls';
  ctrl.innerHTML = `<select id="fType"><option value="">Tất cả loại</option>` +
    [...new Set(DATA.nodes.map(n=>n.group))].sort().map(t=>`<option>${t}</option>`).join('') +
    `</select><select id="fDeg"><option value="0">Mọi node</option>` +
    [1,2,3,5,8,12].map(d=>`<option value="${d}">Degree ≥ ${d}</option>`).join('') +
    `</select><input id="fSearch" placeholder="Tìm entity...">`;
  document.body.insertBefore(ctrl, legendDiv.nextSibling);

  const container = document.createElement('div');
  container.id = 'graph'; container.style.height='720px';
  document.body.insertBefore(container, ctrl.nextSibling);

  const colorMap = {};
  DATA.legend.forEach(l => colorMap[l.type] = l.color);

  let network;
  function render(fType, minDeg, search) {
    const nodes = DATA.nodes.filter(n =>
      (!fType || n.group === fType) && n.value >= minDeg &&
      (!search || n.label.toLowerCase().includes(search.toLowerCase())));
    const ids = new Set(nodes.map(n=>n.id));
    const edges = DATA.edges.filter(e => ids.has(e.from) && ids.has(e.to));
    nodes.forEach(n => n.color = { background: colorMap[n.group] || '#888' });
    network = new vis.Network(container,
      { nodes: new vis.DataSet(nodes), edges: new vis.DataSet(edges) },
      { groups: {}, physics: { stabilization: { iterations: 250 } },
        interaction: { hover: true, tooltipDelay: 120 },
        nodes: { shape: 'dot', font: { size: 11 } } });
  }
  document.getElementById('fType').onchange = e => render(e.target.value, +document.getElementById('fDeg').value, document.getElementById('fSearch').value);
  document.getElementById('fDeg').onchange = e => render(document.getElementById('fType').value, +e.target.value, document.getElementById('fSearch').value);
  document.getElementById('fSearch').oninput = e => render(document.getElementById('fType').value, +document.getElementById('fDeg').value, e.target.value);
  render('', 1, '');
} else {
  // ---- trace mode ----
  const container = document.getElementById('graph');
  const anchorIds = new Set(DATA.nodes.filter(n=>n.borderWidth>=4).map(n=>n.id));
  DATA.nodes.forEach(n => {
    if (!n.color) n.color = {};
  });
  const network = new vis.Network(container,
    { nodes: new vis.DataSet(DATA.nodes), edges: new vis.DataSet(DATA.edges) },
    { physics: { stabilization: { iterations: 200 } },
      interaction: { hover: true, tooltipDelay: 120 },
      nodes: { shape: 'dot', font: { size: 11 } },
      edges: { font: { size: 9, face: 'Segoe UI' } } });
}
"""


# patch: thay __SCRIPT__ lúc render (module-level, đơn giản)
_ORIG = _HTML_TMPL
_HTML_TMPL = _ORIG.replace("__SCRIPT__", _render_script())
