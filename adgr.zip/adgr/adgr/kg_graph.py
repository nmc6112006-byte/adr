"""Xây dựng & merge Knowledge Graph (Section 4.3).

- Entity key = tên chuẩn hoá (case-insensitive); mention lặp gộp thành 1 node,
  ghi nhận tần suất + union mô tả + union source chunks
- Relation key = (source_id, target_id); lặp -> gộp keywords/description, union chunks
- Hướng relation được giữ nguyên lúc trích xuất (source -> target), nhưng khi
  truy vấn one-hop đồ thị được duyệt vô hướng (Eq.8 của paper)
"""
from __future__ import annotations

import json
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Set, Tuple, Optional

from .kg_extract import ChunkExtraction
from .utils import norm_name, sha1, write_json, read_json, get_logger

log = get_logger("adgr.kg")


@dataclass
class Entity:
    id: str
    name: str
    type: str
    description: str = ""
    source_chunk_ids: Set[str] = field(default_factory=set)
    mention_count: int = 0

    def merge_desc(self, desc: str) -> None:
        if not desc:
            return
        if not self.description:
            self.description = desc
        elif desc.lower() != self.description.lower() and desc.lower() not in self.description.lower():
            if len(self.description) < 300:
                self.description = self.description + " " + desc

    def to_json(self) -> dict:
        d = asdict(self)
        d["source_chunk_ids"] = sorted(self.source_chunk_ids)
        return d


@dataclass
class Relation:
    id: str
    source_id: str
    target_id: str
    keywords: str = ""
    description: str = ""
    source_chunk_ids: Set[str] = field(default_factory=set)

    def merge(self, kw: str, desc: str, chunk_ids: Set[str]) -> None:
        if kw and kw.lower() not in self.keywords.lower():
            self.keywords = (self.keywords + ", " + kw).strip(", ")[:120]
        if desc and desc.lower() not in self.description.lower() and len(self.description) < 300:
            self.description = (self.description + " " + desc).strip()
        self.source_chunk_ids |= chunk_ids

    def to_json(self) -> dict:
        d = asdict(self)
        d["source_chunk_ids"] = sorted(self.source_chunk_ids)
        return d


class KnowledgeGraph:
    def __init__(self):
        self.entities: Dict[str, Entity] = {}
        self.relations: Dict[str, Relation] = {}
        # adjacency vô hướng: ent_id -> set(rel_id)
        self.adj: Dict[str, Set[str]] = defaultdict(set)
        self._name_index: Dict[str, str] = {}
        self._rel_index: Dict[Tuple[str, str], str] = {}

    # ---------------- construction ----------------
    def add_extraction(self, ext: ChunkExtraction) -> None:
        name_to_id: Dict[str, str] = {}
        for e in ext.entities:
            ent_id = self._ensure_entity(e.name, e.type, e.description)
            name_to_id[norm_name(e.name)] = ent_id
        # cho phép entity chưa khai báo trong relation (được nhắc trong relation)
        for r in ext.relations:
            src_id = name_to_id.get(norm_name(r.source)) or self._ensure_entity(r.source, "Other", "")
            tgt_id = name_to_id.get(norm_name(r.target)) or self._ensure_entity(r.target, "Other", "")
            if src_id == tgt_id:
                continue
            self._ensure_relation(src_id, tgt_id, r.keywords, r.description, ext.chunk_id)

    def _ensure_entity(self, name: str, etype: str, desc: str) -> str:
        key = norm_name(name)
        if key in self._name_index:
            ent = self.entities[self._name_index[key]]
            ent.mention_count += 1
            ent.merge_desc(desc)
            return ent.id
        ent_id = "ent_" + sha1(key)
        ent = Entity(id=ent_id, name=name.strip(), type=etype,
                     description=desc, mention_count=1)
        self.entities[ent_id] = ent
        self._name_index[key] = ent_id
        return ent_id

    def _ensure_relation(self, src_id: str, tgt_id: str, kw: str, desc: str,
                         chunk_id: str) -> str:
        key = (src_id, tgt_id)
        if key in self._rel_index:
            rel = self.relations[self._rel_index[key]]
            rel.merge(kw, desc, {chunk_id})
            self.adj[src_id].add(rel.id)
            self.adj[tgt_id].add(rel.id)
            return rel.id
        rel_id = "rel_" + sha1(src_id + "->" + tgt_id)
        rel = Relation(id=rel_id, source_id=src_id, target_id=tgt_id,
                       keywords=kw, description=desc, source_chunk_ids={chunk_id})
        self.relations[rel_id] = rel
        self._rel_index[key] = rel_id
        self.adj[src_id].add(rel_id)
        self.adj[tgt_id].add(rel_id)
        return rel_id

    # ---------------- accessors ----------------
    def incident_relations(self, ent_id: str) -> List[Relation]:
        return [self.relations[rid] for rid in self.adj.get(ent_id, ())]

    def endpoints(self, rel: Relation) -> Tuple[Entity, Entity]:
        return self.entities[rel.source_id], self.entities[rel.target_id]

    def entity_edge_text(self, rel: Relation) -> str:
        """Biểu diễn văn bản của edge (Sec 3.4): keywords + source + target + description."""
        s, t = self.endpoints(rel)
        return f"{rel.keywords} | {s.name} | {t.name} | {rel.description}"

    def linked_chunks_of_entities(self, ent_ids: List[str]) -> Set[str]:
        out: Set[str] = set()
        for eid in ent_ids:
            e = self.entities.get(eid)
            if e:
                out |= e.source_chunk_ids
        return out

    def linked_chunks_of_relations(self, rel_ids: List[str]) -> Set[str]:
        out: Set[str] = set()
        for rid in rel_ids:
            r = self.relations.get(rid)
            if r:
                out |= r.source_chunk_ids
        return out

    # ---------------- statistics (Bảng 1 paper) ----------------
    def stats(self) -> dict:
        n_ent = len(self.entities)
        n_rel = len(self.relations)
        # bậc trung bình (vô hướng)
        degs = [len(self.adj.get(eid, ())) for eid in self.entities]
        avg_deg = round(sum(degs) / n_ent, 2) if n_ent else 0.0
        max_deg = max(degs) if degs else 0
        # DSER: tỉ lệ entity thuộc 10 loại chuyên ngành (khác Other)
        domain = sum(1 for e in self.entities.values() if e.type != "Other")
        dser = round(100 * domain / n_ent, 2) if n_ent else 0.0
        # LCR: largest connected component
        lcr = self._lcr()
        # Average clustering coefficient (vô hướng)
        acc = self._avg_clustering()
        return {
            "num_entities": n_ent,
            "num_relations": n_rel,
            "avg_degree_undirected": avg_deg,
            "max_degree": max_deg,
            "dser_pct": dser,
            "lcr_pct": round(100 * lcr, 2) if n_ent else 0.0,
            "avg_clustering": acc,
        }

    def _lcr(self) -> float:
        if not self.entities:
            return 0.0
        seen: Set[str] = set()
        largest = 0
        for start in self.entities:
            if start in seen:
                continue
            comp = 0
            dq = deque([start])
            seen.add(start)
            while dq:
                v = dq.popleft()
                comp += 1
                for rid in self.adj.get(v, ()):
                    r = self.relations[rid]
                    other = r.target_id if r.source_id == v else r.source_id
                    if other not in seen:
                        seen.add(other)
                        dq.append(other)
            largest = max(largest, comp)
        return largest / len(self.entities)

    def _avg_clustering(self) -> float:
        # C_i = số cạnh giữa hàng xóm / (k*(k-1)/2)
        vals = []
        for eid, rels in self.adj.items():
            neighbors: Set[str] = set()
            for rid in rels:
                r = self.relations[rid]
                other = r.target_id if r.source_id == eid else r.source_id
                neighbors.add(other)
            k = len(neighbors)
            if k < 2:
                continue
            links = 0
            neigh_list = list(neighbors)
            for i in range(len(neigh_list)):
                for j in range(i + 1, len(neigh_list)):
                    a, b = neigh_list[i], neigh_list[j]
                    for rid in self.adj.get(a, ()):
                        r = self.relations[rid]
                        other = r.target_id if r.source_id == a else r.source_id
                        if other == b:
                            links += 1
                            break
            vals.append(links / (k * (k - 1) / 2))
        return round(sum(vals) / len(vals), 4) if vals else 0.0

    # ---------------- IO ----------------
    def save(self, out_dir: Path) -> None:
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        write_json([e.to_json() for e in self.entities.values()], out_dir / "entities.json")
        write_json([r.to_json() for r in self.relations.values()], out_dir / "relations.json")

    @classmethod
    def load(cls, out_dir: Path) -> "KnowledgeGraph":
        out_dir = Path(out_dir)
        kg = cls()
        for d in read_json(out_dir / "entities.json"):
            e = Entity(id=d["id"], name=d["name"], type=d["type"],
                       description=d.get("description", ""),
                       source_chunk_ids=set(d.get("source_chunk_ids", [])),
                       mention_count=d.get("mention_count", 1))
            kg.entities[e.id] = e
            kg._name_index[norm_name(e.name)] = e.id
        for d in read_json(out_dir / "relations.json"):
            r = Relation(id=d["id"], source_id=d["source_id"], target_id=d["target_id"],
                         keywords=d.get("keywords", ""), description=d.get("description", ""),
                         source_chunk_ids=set(d.get("source_chunk_ids", [])))
            kg.relations[r.id] = r
            kg._rel_index[(r.source_id, r.target_id)] = r.id
            kg.adj[r.source_id].add(r.id)
            kg.adj[r.target_id].add(r.id)
        return kg
