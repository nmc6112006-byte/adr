"""ADGR Retrieval Pipeline — tái hiện chính xác Algorithm 1 (Eq.3-21).

Pipeline (Blocks 2-5 của paper):
  Block 2: trích xuất Kl (low-level), Kh (high-level) bằng LLM
  Block 3: Overlap-aware hybrid anchor retrieval
      - Eq.3 : B(q)  = union BM25_kb(k, V) theo từng keyword (top-d)
      - Eq.4 : D(tau)= union top-d dense (V khong bao gom B_k), cos >= tau_anchor
      - Eq.5/6: s_anchor = min(1, max cos + delta * f(v))  (overlap bonus)
      - Eq.7 : A(q) = Top-k theo s_anchor
  Block 4: Query-aware semantic edge selection
      - Eq.8 : N(v_i) = edges incident (vô hướng)
      - Eq.9 : s_sem(q,e) = cos(z_q, z_e)
      - Eq.10: lọc s_sem >= tau_edge
      - Eq.11: s_edge = alpha*s_anchor + beta*s_sem (global ranking)
      - Eq.12: Top-m mỗi anchor; Eq.13: Top-N_max toàn cục
  Block 5: Multi-source evidence aggregation
      - Eq.14: E_glob = Top-n_g(cos(z_Kh, z_e)) trên TOÀN BỘ relations
      - Eq.15: T_s = Top-n_s(cos(z_q, z_t)) trên chunks
      - Eq.16: pi(S): chunk nguồn, xếp theo cos với query, giữ floor(r*n/2)
      - Eq.18: Round-robin interleave + dedup theo chunk_id
      - Eq.19/20: cross-encoder rerank -> Top-n_c dưới budget L_max

Mọi bước trung gian đều ghi vào RetrievalTrace phục vụ visualization/CLI.
"""
from __future__ import annotations

import json
import math
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple

from .config import ADGRConfig
from .embeddings import EmbeddingBackend
from .kg_prompts import KEYWORD_SYSTEM, KEYWORD_USER_TMPL
from .llm import LLMBackend
from .rerank import RerankerBackend
from .store import AdgrStore
from .utils import get_logger, estimate_tokens
from .vitoken import keywords_heuristic

log = get_logger("adgr.retrieval")


# =====================================================================
# Trace structures
# =====================================================================
@dataclass
class TraceKeywords:
    low_level: List[str] = field(default_factory=list)
    high_level: List[str] = field(default_factory=list)
    source: str = "mock"          # "llm" | "heuristic"
    latency_ms: float = 0.0


@dataclass
class TraceAnchor:
    entity_id: str
    name: str
    type: str
    score: float
    cos: float                    # cos keyword-entity tốt nhất
    via_bm25: bool = False
    via_dense: bool = False
    overlap: bool = False


@dataclass
class TraceEdge:
    relation_id: str
    source_name: str
    target_name: str
    keywords: str
    s_sem: float
    s_edge: float
    anchor_name: str


@dataclass
class TracePath:
    tv: List[str] = field(default_factory=list)   # chunk ids từ entities
    te: List[str] = field(default_factory=list)   # từ selected edges
    tg: List[str] = field(default_factory=list)   # từ global relations
    ts: List[Tuple[str, float]] = field(default_factory=list)  # (chunk, cos) direct


@dataclass
class RetrievalTrace:
    query: str = ""
    keywords: Optional[TraceKeywords] = None
    anchors: List[TraceAnchor] = field(default_factory=list)
    edges: List[TraceEdge] = field(default_factory=list)
    global_edges: List[Dict] = field(default_factory=list)  # rel_id + cos
    paths: Optional[TracePath] = None
    merged: List[str] = field(default_factory=list)         # chunk ids sau round-robin
    reranked: List[Tuple[str, float]] = field(default_factory=list)  # (chunk, score)
    final_chunks: List[str] = field(default_factory=list)
    timings: Dict[str, float] = field(default_factory=dict)
    config: Dict = field(default_factory=dict)

    def to_json(self) -> dict:
        return {
            "query": self.query,
            "keywords": self.keywords.__dict__ if self.keywords else None,
            "anchors": [a.__dict__ for a in self.anchors],
            "edges": [e.__dict__ for e in self.edges],
            "global_edges": self.global_edges,
            "paths": self.paths.__dict__ if self.paths else None,
            "merged": self.merged,
            "reranked": self.reranked,
            "final_chunks": self.final_chunks,
            "timings": self.timings,
            "config": self.config,
        }


# =====================================================================
# Main pipeline
# =====================================================================
class ADGRRetriever:
    def __init__(self, store: AdgrStore, cfg: ADGRConfig,
                 llm: LLMBackend, embedder: EmbeddingBackend,
                 reranker: RerankerBackend):
        self.store = store
        self.cfg = cfg
        self.llm = llm
        self.embedder = embedder
        self.reranker = reranker
        self.rc = cfg.retrieval

    # ---------------------------------------------------------------
    # Block 2: keyword extraction
    # ---------------------------------------------------------------
    def extract_keywords(self, query: str) -> TraceKeywords:
        t0 = time.time()
        tk = TraceKeywords()
        try:
            raw = self.llm.chat(
                [{"role": "system", "content": KEYWORD_SYSTEM},
                 {"role": "user", "content": KEYWORD_USER_TMPL.format(question=query)}],
                temperature=0.0, max_tokens=256, json_mode=True)
            data = json.loads(_extract_json(raw))
            kl = [k.strip() for k in data.get("low_level", []) if k.strip()]
            kh = [k.strip() for k in data.get("high_level", []) if k.strip()]
            if kl:
                tk.low_level, tk.high_level, tk.source = kl, kh or kl, "llm"
        except Exception as e:
            log.warning(f"LLM keyword extraction lỗi ({e}) -> fallback heuristic")
        if not tk.low_level:
            # fallback heuristic (không phụ thuộc LLM)
            kl = keywords_heuristic(query, max_kw=6)
            tk.low_level = kl[:6] or [query.strip()[:40]]
            tk.high_level = kl[:3] or tk.low_level[:1]
            tk.source = "heuristic"
        tk.latency_ms = (time.time() - t0) * 1000
        return tk

    # ---------------------------------------------------------------
    # Block 3: overlap-aware hybrid anchor retrieval (Eq.3-7)
    # mode="no_anchor" -> chọn anchor bằng dense thuần (ablation Bảng 7)
    # ---------------------------------------------------------------
    def retrieve_anchors(self, query: str, kl: List[str], mode: str = "full") -> List[TraceAnchor]:
        t0 = time.time()
        d, tau, delta, k = self.rc.d, self.rc.tau_anchor, self.rc.delta, self.rc.k
        kg = self.store.kg
        ve = self.store.vec_entity
        bm25 = self.store.bm25_entity

        # trạng thái theo entity id
        best_cos: Dict[str, float] = {}       # cos tốt nhất với bất kỳ keyword nào
        via_bm25: Set[str] = set()
        via_dense: Set[str] = set()
        overlap_kw: Dict[str, int] = {}       # số keyword gây overlap
        kw_cos: Dict[str, float] = {}

        for kw in kl:
            z_kw = self.embedder.encode_one(kw, is_query=True)

            # --- Eq.3: nhánh BM25 trên entity index (name + description) ---
            # ablation no_anchor: bỏ hẳn nhánh BM25 (dense-only anchor)
            b_hits = bm25.search(kw, top_k=d) if mode == "full" else []
            b_keys = {key for key, _ in b_hits}

            # --- Eq.4 + cơ chế overlap (đúng paper):
            # quét dense ranking trên cửa sổ 4d + |B_k| để phát hiện overlap;
            # nhánh dense thực sự chỉ đóng góp tối đa d entity NGOÀI B_k có cos >= tau
            window = 4 * d + len(b_keys)
            dense_hits = ve.search(z_kw, top_k=window)
            dense_added = 0
            for ent_id, cosv in dense_hits:
                kw_cos[ent_id] = max(kw_cos.get(ent_id, 0.0), cosv)
                if ent_id in b_keys:
                    # Eq.6: overlap khi cả hai kênh cùng trả cho keyword này
                    # và cos đạt ngưỡng; bonus áp 1 lần cho mỗi keyword
                    if cosv >= tau:
                        overlap_kw[ent_id] = overlap_kw.get(ent_id, 0) + 1
                elif cosv >= tau and dense_added < d:
                    via_dense.add(ent_id)
                    dense_added += 1

            for key in b_keys:
                via_bm25.add(key)

            # cos cho entity BM25 (Eq.4/5 dùng z_v là embedding TÊN entity)
            for key in b_keys:
                pos = ve.id_pos.get(key)
                if pos is not None:
                    cosv = float(ve.vecs[pos] @ _norm(z_kw))
                    kw_cos[key] = max(kw_cos.get(key, 0.0), cosv)

        # --- Eq.5: s_anchor = min(1, max cos + delta * f(v)) ---
        candidates = (via_bm25 | via_dense)
        anchors: List[TraceAnchor] = []
        for ent_id in candidates:
            ent = kg.entities.get(ent_id)
            if ent is None:
                continue
            cosv = kw_cos.get(ent_id, 0.0)
            # f(v)=1 nếu cả hai kênh cùng trả cho một keyword (Eq.6)
            f_v = 1 if overlap_kw.get(ent_id, 0) > 0 else 0
            score = min(1.0, cosv + delta * f_v)
            anchors.append(TraceAnchor(
                entity_id=ent_id, name=ent.name, type=ent.type, score=score,
                cos=cosv, via_bm25=ent_id in via_bm25, via_dense=ent_id in via_dense,
                overlap=bool(f_v)))
        anchors.sort(key=lambda a: -a.score)
        anchors = anchors[:k]
        self._last_anchor_scores = {a.entity_id: a.score for a in anchors}
        self._last_anchors = anchors
        if self.cfg.verbose:
            log.info(f"[anchors] {len(anchors)} anchors: " +
                     ", ".join(f"{a.name}({a.score:.2f})" for a in anchors[:8]))
        return anchors

    # ---------------------------------------------------------------
    # Block 4: query-aware semantic edge selection (Eq.8-13)
    # mode="no_edge_filter" -> bỏ ngưỡng tau_edge và quota m (ablation Bảng 7)
    # ---------------------------------------------------------------
    def select_edges(self, query: str, anchors: List[TraceAnchor], mode: str = "full") -> List[TraceEdge]:
        t0 = time.time()
        tau_edge, m, n_max = self.rc.tau_edge, self.rc.m, self.rc.n_max
        if mode == "no_edge_filter":
            tau_edge, m = 0.0, 10 ** 9
        alpha, beta = self.rc.alpha, self.rc.beta
        kg = self.store.kg
        vr = self.store.vec_relation

        z_q = _norm(self.embedder.encode_one(query, is_query=True))

        # edge text embedding cache (relation_id -> vector)
        rel_vecs: Dict[str, object] = {}

        def rel_vec(rel_id: str):
            if rel_id not in rel_vecs:
                pos = vr.id_pos.get(rel_id)
                if pos is None:
                    rel_vecs[rel_id] = None
                else:
                    rel_vecs[rel_id] = vr.vecs[pos]
            return rel_vecs[rel_id]

        per_anchor_selected: List[Tuple[str, str, float]] = []  # (anchor_id, rel_id, s_sem)
        seen_rel: Set[str] = set()

        for anchor in anchors:
            # --- Eq.8: one-hop, vô hướng ---
            inc = kg.incident_relations(anchor.entity_id)
            cands: List[Tuple[str, float]] = []
            for rel in inc:
                if rel.id in seen_rel:
                    continue
                v = rel_vec(rel.id)
                if v is None:      # edge không có embedding -> loại (đúng paper)
                    continue
                # --- Eq.9 ---
                s_sem = float(v @ z_q)
                cands.append((rel.id, s_sem))
            if not cands:
                continue
            # --- Eq.10: ngưỡng ---
            cands = [(rid, s) for rid, s in cands if s >= tau_edge]
            if not cands:
                continue
            # --- Eq.12: top-m theo s_sem cho anchor này ---
            cands.sort(key=lambda x: -x[1])
            for rid, s in cands[:m]:
                per_anchor_selected.append((anchor.entity_id, rid, s))
                seen_rel.add(rid)

        # --- Eq.11 + Eq.13: global ranking theo s_edge, cap N_max ---
        # edge giữ 1 lần với anchor có s_anchor cao nhất
        best_by_rel: Dict[str, Tuple[float, str, float]] = {}  # rel -> (s_edge, anchor_id, s_sem)
        for anchor_id, rid, s_sem in per_anchor_selected:
            s_anchor = self._last_anchor_scores.get(anchor_id, 0.0)
            s_edge = alpha * s_anchor + beta * s_sem
            cur = best_by_rel.get(rid)
            if cur is None or s_edge > cur[0]:
                best_by_rel[rid] = (s_edge, anchor_id, s_sem)

        ranked = sorted(best_by_rel.items(), key=lambda kv: -kv[1][0])[:n_max]

        edges: List[TraceEdge] = []
        for rid, (s_edge, anchor_id, s_sem) in ranked:
            rel = kg.relations[rid]
            s_ent, t_ent = kg.endpoints(rel)
            edges.append(TraceEdge(
                relation_id=rid, source_name=s_ent.name, target_name=t_ent.name,
                keywords=rel.keywords, s_sem=s_sem, s_edge=s_edge,
                anchor_name=kg.entities[anchor_id].name))
        self._last_selected_edges = [e.relation_id for e in edges]
        if self.cfg.verbose:
            log.info(f"[edges] chọn {len(edges)} edges (tau_edge={tau_edge}, m={m}, N_max={n_max})")
        return edges

    # ---------------------------------------------------------------
    # Block 5a: global relation + direct semantic retrieval (Eq.14-15)
    # ---------------------------------------------------------------
    def global_and_direct(self, query: str, kh: List[str]) -> Tuple[List[Dict], List[Tuple[str, float]]]:
        t0 = time.time()
        n_g, n_s = self.rc.n_g, self.rc.n_s
        vr, vc = self.store.vec_relation, self.store.vec_chunk

        # --- Eq.14: Kh ghép chung 1 chuỗi, nhúng như 1 query duy nhất (paper) ---
        kh_str = ", ".join(kh) if kh else query
        z_kh = _norm(self.embedder.encode_one(kh_str, is_query=True))
        glob = vr.search(z_kh, top_k=n_g)
        global_edges = [{"relation_id": rid, "s_sem": s} for rid, s in glob]

        # --- Eq.15: direct semantic trên chunk ---
        z_q = _norm(self.embedder.encode_one(query, is_query=True))
        direct = vc.search(z_q, top_k=n_s)

        if self.cfg.verbose:
            log.info(f"[global] {len(global_edges)} relations | [direct] {len(direct)} chunks")
        return global_edges, direct

    # ---------------------------------------------------------------
    # Block 5b: aggregation pi + round-robin + rerank (Eq.16-20)
    # ---------------------------------------------------------------
    def aggregate(self, query: str, anchors: List[TraceAnchor],
                  edges: List[TraceEdge], global_edges: List[Dict],
                  direct: List[Tuple[str, float]]) -> Tuple[TracePath, List[str]]:
        t0 = time.time()
        kg = self.store.kg
        vc = self.store.vec_chunk
        r = self.rc.r
        z_q = _norm(self.embedder.encode_one(query, is_query=True))

        # --- Eq.16: pi(S) - query-conditioned source-chunk selection ---
        def pi(graph_element_ids: List[str], is_relation: bool) -> List[str]:
            if is_relation:
                chunk_set = kg.linked_chunks_of_relations(graph_element_ids)
            else:
                chunk_set = kg.linked_chunks_of_entities(graph_element_ids)
            n_elems = len(graph_element_ids)
            budget = max(1, math.floor(r * n_elems / 2)) if n_elems else 0
            if not chunk_set:
                return []
            chunk_ids = list(chunk_set)
            pos_idx = [vc.id_pos[cid] for cid in chunk_ids if cid in vc.id_pos]
            sims = vc.vecs[pos_idx] @ z_q
            pairs = sorted(zip([cid for cid in chunk_ids if cid in vc.id_pos], sims),
                           key=lambda x: -x[1])
            return [cid for cid, _ in pairs[:budget]]

        # A'(q): anchor incident tới >= 1 edge được chọn
        selected_rel_ids = [e.relation_id for e in edges]
        incident_anchor_ids: Set[str] = set()
        for rid in selected_rel_ids:
            rel = kg.relations[rid]
            incident_anchor_ids.add(rel.source_id)
            incident_anchor_ids.add(rel.target_id)
        a_prime = [a.entity_id for a in anchors if a.entity_id in incident_anchor_ids]

        # V(E_glob): endpoint entities của global relations
        glob_rel_ids = [g["relation_id"] for g in global_edges]
        v_glob: List[str] = []
        for rid in glob_rel_ids:
            rel = kg.relations.get(rid)
            if rel:
                v_glob += [rel.source_id, rel.target_id]

        tv = pi(a_prime + v_glob, is_relation=False)
        te = pi(selected_rel_ids, is_relation=True)
        tg = pi(glob_rel_ids, is_relation=True)

        # --- Eq.18: round-robin interleave + dedup (dùng bản copy để giữ trace) ---
        ts_ids = [c for c, _ in direct]
        merged: List[str] = []
        seen: Set[str] = set()
        queues = [list(tv), list(te), list(tg), list(ts_ids)]
        qi = 0
        while any(queues):
            q = queues[qi % 4]
            qi += 1
            if q:
                cid = q.pop(0)
                if cid not in seen:
                    seen.add(cid)
                    merged.append(cid)
        paths = TracePath(tv=tv, te=te,
                          tg=tg, ts=direct)
        if self.cfg.verbose:
            log.info(f"[aggregate] Tv={len(tv)} Te={len(te)} Tg={len(tg)} Ts={len(ts_ids)} "
                     f"-> merged={len(merged)}")
        return paths, merged

    def rerank_and_select(self, query: str, merged: List[str]) -> List[Tuple[str, float]]:
        """Eq.19-20: cross-encoder rerank + Top-n_c dưới budget L_max."""
        if not merged:
            return []
        chunks = [self.store.chunk_by_id[cid] for cid in merged if cid in self.store.chunk_by_id]
        docs = [c.content for c in chunks]

        if self.cfg.rerank_backend == "none":
            # ablation: giữ thứ tự merged (đã theo cosine ưu tiên các đường)
            scored = [(c.chunk_id, 0.0) for c in chunks]
        else:
            scores = self.reranker.score(query, docs)
            scored = sorted(zip([c.chunk_id for c in chunks], scores.tolist()),
                            key=lambda x: -x[1])

        # --- Eq.20: budget n_c và L_max ---
        n_c = self.rc.n_c
        remaining = self.rc.max_context_tokens
        out: List[Tuple[str, float]] = []
        for cid, sc in scored:
            ch = self.store.chunk_by_id[cid]
            cost = estimate_tokens(f"{ch.doc_title}\n{ch.content}\n\n")
            if len(out) >= n_c or cost > remaining:
                break
            out.append((cid, sc))
            remaining -= cost
        return out

    # ---------------------------------------------------------------
    # Full pipeline
    # mode: full | dense_only | no_anchor | no_edge_filter (ablation Bảng 7)
    # ---------------------------------------------------------------
    def retrieve(self, query: str, use_rerank: bool = True,
                 mode: str = "full") -> Tuple[List[Chunk], RetrievalTrace]:
        t_start = time.time()
        if mode == "dense_only":
            # Dense Retrieval Only: không dùng đồ thị (ablation Bảng 7)
            z_q = _norm(self.embedder.encode_one(query, is_query=True))
            direct = self.store.vec_chunk.search(z_q, top_k=self.rc.n_c + 5)
            tr = RetrievalTrace(query=query, config={"mode": "dense_only"})
            tr.keywords = TraceKeywords(low_level=[], high_level=[], source="none")
            tr.merged = [cid for cid, _ in direct]
            if use_rerank:
                final = self.rerank_and_select(query, tr.merged)
            else:
                final = direct[: self.rc.n_c]
            tr.reranked = [(c, s) for c, s in final]
            tr.final_chunks = [c for c, _ in final]
            tr.timings["total_ms"] = (time.time() - t_start) * 1000
            return [self.store.chunk_by_id[c] for c in tr.final_chunks], tr
        if mode == "no_rerank":
            use_rerank = False
        tr = RetrievalTrace(query=query, config={
            "mode": mode,
            "d": self.rc.d, "tau_anchor": self.rc.tau_anchor, "delta": self.rc.delta,
            "k": self.rc.k, "alpha": self.rc.alpha, "beta": self.rc.beta,
            "tau_edge": self.rc.tau_edge, "m": self.rc.m, "n_max": self.rc.n_max,
            "n_g": self.rc.n_g, "n_s": self.rc.n_s, "r": self.rc.r,
            "n_c": self.rc.n_c, "max_context_tokens": self.rc.max_context_tokens,
            "rerank": self.cfg.rerank_backend if use_rerank else "none",
        })

        # Block 2
        tk = self.extract_keywords(query)
        tr.keywords = tk
        tr.timings["keywords_ms"] = tk.latency_ms

        # Block 3
        t0 = time.time()
        anchors = self.retrieve_anchors(query, tk.low_level, mode=mode)
        tr.anchors = anchors
        tr.timings["anchors_ms"] = (time.time() - t0) * 1000

        # Block 4
        t0 = time.time()
        edges = self.select_edges(query, anchors, mode=mode)
        tr.edges = edges
        tr.timings["edges_ms"] = (time.time() - t0) * 1000

        # Block 5a
        t0 = time.time()
        global_edges, direct = self.global_and_direct(query, tk.high_level)
        tr.global_edges = global_edges
        tr.timings["global_direct_ms"] = (time.time() - t0) * 1000

        # Block 5b
        t0 = time.time()
        paths, merged = self.aggregate(query, anchors, edges, global_edges, direct)
        tr.paths = paths
        tr.merged = merged
        tr.timings["aggregate_ms"] = (time.time() - t0) * 1000

        # Eq.19-20
        t0 = time.time()
        if use_rerank:
            final = self.rerank_and_select(query, merged)
        else:
            scored = [(cid, 0.0) for cid in merged[: self.rc.n_c]]
            out = []
            remaining = self.rc.max_context_tokens
            for cid, sc in scored:
                ch = self.store.chunk_by_id[cid]
                cost = estimate_tokens(f"{ch.doc_title}\n{ch.content}\n\n")
                if len(out) >= self.rc.n_c or cost > remaining:
                    break
                out.append((cid, sc))
                remaining -= cost
            final = out
        tr.reranked = [(c, s) for c, s in final]
        tr.final_chunks = [c for c, _ in final]
        tr.timings["rerank_ms"] = (time.time() - t0) * 1000
        tr.timings["total_ms"] = (time.time() - t_start) * 1000

        final_chunks = [self.store.chunk_by_id[cid] for cid in tr.final_chunks]
        if self.cfg.verbose:
            log.info(f"[final] {len(final_chunks)} chunks | retrieval "
                     f"{tr.timings['total_ms']:.0f} ms")
        return final_chunks, tr


# ---------------- helpers ----------------
def _norm(v):
    import numpy as np
    v = np.asarray(v, dtype=np.float32)
    n = np.linalg.norm(v) + 1e-12
    return v / n


def _extract_json(raw: str) -> str:
    """Trích JSON object từ text LLM (bỏ markdown fence v.v.)."""
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    start = raw.find("{")
    end = raw.rfind("}")
    if start >= 0 and end > start:
        return raw[start:end + 1]
    return raw
