"""Entity schema của ViMedGraph (Section 4.3 + supplementary của paper)."""
from __future__ import annotations

from typing import List

# 10 loại chuyên ngành + Other - đúng supplementary
ENTITY_TYPES = [
    "Disease",
    "Symptom",
    "Drug",
    "Chemical compound",
    "Protein",
    "Anatomy",
    "Biological process",
    "Exposure",
    "Diagnostic test",
    "Treatment method",
    "Other",
]

TYPE_COLORS = {  # dùng cho visualization
    "Disease": "#e05666",
    "Symptom": "#f0932b",
    "Drug": "#22a6b3",
    "Chemical compound": "#6ab04c",
    "Protein": "#8e44ad",
    "Anatomy": "#e84393",
    "Biological process": "#7f8fa6",
    "Exposure": "#c23616",
    "Diagnostic test": "#4834d4",
    "Treatment method": "#00a8ff",
    "Other": "#95a5a6",
}


def normalize_type(t: str, valid: List[str] | None = None) -> str:
    t = (t or "").strip()
    valid = valid or ENTITY_TYPES
    tl = t.lower()
    for v in valid:
        if tl == v.lower():
            return v
    # xấp xỉ: chứa tên loại
    for v in valid:
        if v.lower() in tl:
            return v
    return "Other"
