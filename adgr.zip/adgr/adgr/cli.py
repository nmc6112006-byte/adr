"""CLI ADGR — tất cả các bước qua dòng lệnh.

Ví dụ:
  python -m adgr.cli build-all --data-dir data
  python -m adgr.cli query "A.t Vildagliptin dùng để điều trị bệnh gì?" --show-trace
  python -m adgr.cli eval --ablation
  python -m adgr.cli viz-kg --top 300
  python -m adgr.cli stats
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

from .config import ADGRConfig
from .utils import get_logger, set_seed, write_json

log = get_logger("adgr.cli")


def _parse_overrides(pairs: list | None) -> dict:
    out = {}
    for p in pairs or []:
        if "=" not in p:
            raise SystemExit(f"--set cần dạng key=value, nhận: {p}")
        k, v = p.split("=", 1)
        out[k.strip()] = v.strip()
    return out


def _load_store_and_retriever(cfg: ADGRConfig, data_dir: Path):
    from .store import AdgrStore
    from .embeddings import make_embedder
    from .llm import make_llm
    from .rerank import make_reranker
    from .retrieval import ADGRRetriever

    store = AdgrStore(data_dir)
    if not (data_dir / "chunks.json").exists():
        raise SystemExit(f"Chưa build corpus. Chạy: python -m adgr.cli build-corpus --data-dir {data_dir}")
    store.load_corpus()
    if (data_dir / "kg" / "entities.json").exists():
        store.load_kg()
    if store.is_index_ready():
        store.load_index()
    llm = make_llm(cfg)
    embedder = make_embedder(cfg)
    reranker = make_reranker(cfg)
    retriever = ADGRRetriever(store, cfg, llm, embedder, reranker)
    return store, retriever, embedder


# ------------------------------------------------------------------
def main(argv=None) -> int:
    # parent parser dùng chung: cho phép --config/--data-dir/--set đặt
    # TRƯỚC hoặc SAU subcommand
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--config", default="configs/default.yaml", help="đường dẫn YAML cấu hình")
    common.add_argument("--data-dir", default="data", help="thư mục artifacts")
    common.add_argument("--set", dest="sets", action="append", default=[],
                        help="ghi đè cấu hình, vd --set retrieval.k=20 --set llm_backend=openai_compat")

    p = argparse.ArgumentParser(prog="adgr", description="ADGR - Adaptive Directed Graph Retrieval (re-implementation)",
                                parents=[common])
    sub = p.add_subparsers(dest="cmd", required=True)

    # build commands
    sub.add_parser("build-corpus", parents=[common], help="Tải corpus + structure-aware chunking")
    sub.add_parser("build-kg", parents=[common], help="Trích xuất knowledge graph bằng LLM")
    sub.add_parser("build-index", parents=[common], help="Xây BM25 + dense indices")
    p_all = sub.add_parser("build-all", parents=[common], help="corpus -> kg -> index (pipeline đầy đủ)")
    p_all.add_argument("--skip-kg", action="store_true", help="bỏ qua build KG (đã có)")

    # query
    p_q = sub.add_parser("query", parents=[common], help="Truy vấn ADGR end-to-end")
    p_q.add_argument("question", help="câu hỏi y tế tiếng Việt")
    p_q.add_argument("--show-trace", action="store_true", help="in trace từng bước")
    p_q.add_argument("--no-generate", action="store_true", help="chỉ retrieval, không sinh câu trả lời")
    p_q.add_argument("--mode", default="full",
                     choices=["full", "dense_only", "no_anchor", "no_edge_filter", "no_rerank"],
                     help="chế độ retrieval (ablation Bảng 7)")
    p_q.add_argument("--out", default="", help="lưu kết quả JSON vào file")

    # eval
    p_e = sub.add_parser("eval", parents=[common], help="Chạy evaluation trên QA set")
    p_e.add_argument("--limit", type=int, default=0)
    p_e.add_argument("--ablation", action="store_true", help="chạy cả 4 biến thể ablation")
    p_e.add_argument("--no-judge", action="store_true")
    p_e.add_argument("--out", default="eval_results.json")

    # viz
    p_v = sub.add_parser("viz-kg", parents=[common], help="Xuất HTML đồ thị KG tương tác")
    p_v.add_argument("--top", type=int, default=400, help="số node bậc cao nhất")
    p_v.add_argument("--out", default="outputs/kg.html")
    p_t = sub.add_parser("viz-trace", parents=[common], help="Xuất HTML retrieval trace cho 1 truy vấn")
    p_t.add_argument("question")
    p_t.add_argument("--mode", default="full",
                     choices=["full", "dense_only", "no_anchor", "no_edge_filter", "no_rerank"])
    p_t.add_argument("--out", default="outputs/trace.html")

    # stats
    sub.add_parser("stats", parents=[common], help="Thống kê corpus + KG (giống Bảng 1)")

    args = p.parse_args(argv)
    cfg = ADGRConfig.load(args.config, overrides=_parse_overrides(args.sets))
    set_seed(cfg.seed)
    data_dir = Path(args.data_dir)
    data_dir.mkdir(parents=True, exist_ok=True)

    if args.cmd == "build-corpus":
        from .build_index import build_corpus_stage
        build_corpus_stage(cfg, data_dir)

    elif args.cmd == "build-kg":
        from .build_index import build_kg_stage
        build_kg_stage(cfg, data_dir)

    elif args.cmd == "build-index":
        from .build_index import build_index_stage
        build_index_stage(cfg, data_dir)

    elif args.cmd == "build-all":
        from .build_index import build_corpus_stage, build_kg_stage, build_index_stage
        build_corpus_stage(cfg, data_dir)
        if not args.skip_kg:
            build_kg_stage(cfg, data_dir)
        else:
            log.info("--skip-kg: dùng KG hiện có")
        build_index_stage(cfg, data_dir)

    elif args.cmd == "query":
        store, retriever, _ = _load_store_and_retriever(cfg, data_dir)
        t0 = time.time()
        chunks, trace = retriever.retrieve(args.question, mode=args.mode)
        result = {"query": args.question, "mode": args.mode,
                  "timings": trace.timings,
                  "final_chunks": [c.to_dict() for c in chunks]}
        if not args.no_generate:
            from .generation import generate_answer
            gen = generate_answer(retriever.llm, cfg, args.question, chunks)
            result["answer"] = gen.answer
            result["prompt_tokens_est"] = gen.prompt_tokens_est
            result["output_tokens_est"] = gen.output_tokens_est
        if args.show_trace:
            tr = trace
            print("\n=== ADGR TRACE ===")
            print(f"Kl: {tr.keywords.low_level}\nKh: {tr.keywords.high_level} ({tr.keywords.source})")
            print("\nAnchors:")
            for a in tr.anchors:
                print(f"  {a.name:<28} {a.type:<18} s={a.score:.3f} cos={a.cos:.3f} "
                      f"BM25={int(a.via_bm25)} dense={int(a.via_dense)} ov={int(a.overlap)}")
            print("\nEdges (top):")
            for e in tr.edges[:15]:
                print(f"  [{e.anchor_name}] {e.source_name} -[{e.keywords}]-> {e.target_name} "
                      f"s_sem={e.s_sem:.3f} s_edge={e.s_edge:.3f}")
            print(f"\nMerged={len(tr.merged)} | Final={len(tr.final_chunks)}")
            if "answer" in result:
                print("\n=== ANSWER ===")
                print(result["answer"])
        print("\n=== CONTEXT (top chunks) ===")
        for i, c in enumerate(chunks, 1):
            print(f"[{i}] {c.doc_title} § {' > '.join(c.section_path[:2])} "
                  f"({c.n_tokens_est} tok)")
        if args.out:
            write_json(result, args.out, ensure_ascii=True)
            print(f"\nĐã lưu: {args.out}")

    elif args.cmd == "eval":
        store, retriever, embedder = _load_store_and_retriever(cfg, data_dir)
        from .eval_runner import run_eval
        run_eval(store, cfg, retriever, embedder,
                 out_path=Path(args.out), eval_limit=args.limit,
                 with_ablation=args.ablation, judge=not args.no_judge)

    elif args.cmd == "viz-kg":
        store, _, _ = _load_store_and_retriever(cfg, data_dir)
        from .viz import export_kg_html
        path = export_kg_html(store, Path(args.out), top_n=args.top)
        print(f"Đã xuất: {path}")

    elif args.cmd == "viz-trace":
        store, retriever, _ = _load_store_and_retriever(cfg, data_dir)
        from .viz import export_trace_html
        chunks, trace = retriever.retrieve(args.question, mode=args.mode)
        path = export_trace_html(store, trace, Path(args.out))
        print(f"Đã xuất: {path}")

    elif args.cmd == "stats":
        store = _load_store_and_retriever(cfg, data_dir)[0]
        print("=== CORPUS ===")
        print(f"Documents: {len(store.documents)}")
        print(f"Chunks   : {len(store.chunks)}")
        if store.kg.entities:
            print("\n=== KNOWLEDGE GRAPH (Bảng 1) ===")
            st = store.kg.stats()
            for k, v in st.items():
                print(f"{k:<28}: {v}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
