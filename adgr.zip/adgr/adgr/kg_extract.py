"""Trích xuất KG từ chunk bằng LLM — X(x) = (Vx, Qx) (Section 4.3, Eq.25).

Parser nhận định dạng delimiter <|#|> (đúng supplementary):
  entity<|#|>name<|#|>type<|#|>description
  relation<|#|>source<|#|>target<|#|>keywords<|#|>description
  <|COMPLETE|>
Tự fallback sang JSON nếu backend cấu hình json output.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List

from .config import ADGRConfig
from .kg_schema import normalize_type
from .llm import LLMBackend
from .kg_prompts import EXTRACTION_SYSTEM, EXTRACTION_USER_TMPL
from .utils import get_logger

log = get_logger("adgr.kg_extract")


@dataclass
class ExtractedEntity:
    name: str
    type: str
    description: str


@dataclass
class ExtractedRelation:
    source: str
    target: str
    keywords: str
    description: str


@dataclass
class ChunkExtraction:
    chunk_id: str
    entities: List[ExtractedEntity] = field(default_factory=list)
    relations: List[ExtractedRelation] = field(default_factory=list)


_ENT_RE = re.compile(r"^entity\s*<\|#\|>\s*(.+?)\s*<\|#\|>\s*(.+?)\s*<\|#\|>\s*(.+?)\s*$")
_REL_RE = re.compile(r"^relation\s*<\|#\|>\s*(.+?)\s*<\|#\|>\s*(.+?)\s*<\|#\|>\s*(.+?)\s*<\|#\|>\s*(.+?)\s*$")


def parse_extraction(raw: str, valid_types: List[str],
                     max_entities: int = 20, max_relations: int = 20) -> tuple:
    """Parse output LLM -> (entities, relations)."""
    entities: List[ExtractedEntity] = []
    relations: List[ExtractedRelation] = []
    for line in raw.split("\n"):
        line = line.strip()
        if not line or line.startswith("<|COMPLETE|>") or "<|COMPLETE|>" in line:
            continue
        m = _ENT_RE.match(line)
        if m and len(entities) < max_entities:
            name, etype, desc = m.group(1), m.group(2), m.group(3)
            if name and len(name) <= 120:
                entities.append(ExtractedEntity(
                    name=name.strip(), type=normalize_type(etype, valid_types),
                    description=desc.strip()[:400]))
            continue
        m = _REL_RE.match(line)
        if m and len(relations) < max_relations:
            src, tgt, kw, desc = m.groups()
            if src and tgt and src.strip().lower() != tgt.strip().lower():
                relations.append(ExtractedRelation(
                    source=src.strip(), target=tgt.strip(),
                    keywords=kw.strip()[:80], description=desc.strip()[:400]))
    return entities, relations


def extract_chunk_graph(llm: LLMBackend, cfg: ADGRConfig, chunk_id: str,
                        text: str) -> ChunkExtraction:
    """Gọi LLM trích xuất cho 1 chunk (temperature=0 đúng paper)."""
    sys_prompt = EXTRACTION_SYSTEM.format(entity_types=", ".join(cfg.kg.entity_types))
    user_prompt = EXTRACTION_USER_TMPL.format(text=text[:6000])
    messages = [{"role": "system", "content": sys_prompt},
                {"role": "user", "content": user_prompt}]
    raw = llm.chat(messages, temperature=0.0, max_tokens=cfg.llm.max_tokens)
    ents, rels = parse_extraction(raw, cfg.kg.entity_types,
                                  cfg.kg.max_entities_per_chunk,
                                  cfg.kg.max_relations_per_chunk)
    return ChunkExtraction(chunk_id=chunk_id, entities=ents, relations=rels)
