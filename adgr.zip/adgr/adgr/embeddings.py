"""Embedding backends cho ADGR (mô phỏng embeddinggemma:300m của paper).

- hash_mock : feature-hashing n-gram -> vector 512d deterministic, KHÔNG cần
              tải model. Cosine phản ánh trùng lặp từ/n-gram — đủ để kiểm tra
              toàn bộ pipeline và chạy CI.
- st_local  : sentence-transformers model thật (mặc định
              intfloat/multilingual-e5-small; có thể đổi sang
              google/embeddinggemma-300m giống paper nếu license cho phép).
"""
from __future__ import annotations

import hashlib
import re
from abc import ABC, abstractmethod
from typing import List, Optional

import numpy as np

from .config import ADGRConfig, EmbedConfig
from .utils import get_logger, l2norm

log = get_logger("adgr.embed")


class EmbeddingBackend(ABC):
    name = "base"
    dim: int = 0

    @abstractmethod
    def encode(self, texts: List[str], is_query: bool = False,
               batch_size: int = 64) -> np.ndarray:
        """Trả về ma trận (n, dim) float32 đã chuẩn hoá L2."""
        raise NotImplementedError

    def encode_one(self, text: str, is_query: bool = False) -> np.ndarray:
        return self.encode([text], is_query=is_query)[0]


# =====================================================================
# Hash mock
# =====================================================================
class HashMockEmbedding(EmbeddingBackend):
    name = "hash_mock"
    dim = 512

    _NGRAM_RE = re.compile(r"[^\W\d_]+", re.UNICODE)

    def _features(self, text: str) -> List[str]:
        toks = re.findall(r"\w+", text.lower())
        feats = []
        for t in toks:
            feats.append(t)
        # bi-gram ký tự cho token dài -> bắt được biến thể từ tiếng Việt
        for t in toks:
            if len(t) > 5:
                for i in range(len(t) - 3):
                    feats.append("#" + t[i:i + 4] + "#")
        return feats

    def encode(self, texts: List[str], is_query: bool = False,
               batch_size: int = 64) -> np.ndarray:
        out = np.zeros((len(texts), self.dim), dtype=np.float32)
        for i, text in enumerate(texts):
            for f in self._features(text):
                h = int(hashlib.md5(f.encode("utf-8")).hexdigest(), 16)
                idx = h % self.dim
                sign = 1.0 if (h >> 128) % 2 == 0 else -1.0
                out[i, idx] += sign
        return l2norm(out)


# =====================================================================
# Sentence-Transformers local
# =====================================================================
class STLocalEmbedding(EmbeddingBackend):
    name = "st_local"

    def __init__(self, cfg: EmbedConfig):
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as e:
            raise ImportError(
                "st_local cần 'sentence-transformers' (và torch). "
                "Trên Kaggle: pip install sentence-transformers") from e
        self.cfg = cfg
        log.info(f"[embed] Nạp model {cfg.model} (device={cfg.device}) ...")
        self.model = SentenceTransformer(cfg.model, device=cfg.device)
        self.dim = self.model.get_sentence_embedding_dimension()
        # e5 cần prefix query/passage; embeddinggemma không bắt buộc
        self.use_prefix = "e5" in cfg.model.lower()

    def encode(self, texts: List[str], is_query: bool = False,
               batch_size: Optional[int] = None) -> np.ndarray:
        if not texts:
            return np.zeros((0, self.dim), dtype=np.float32)
        if self.use_prefix:
            pref = self.cfg.query_prefix if is_query else self.cfg.passage_prefix
            texts = [pref + t for t in texts]
        bs = batch_size or self.cfg.batch_size
        vecs = self.model.encode(texts, batch_size=bs, show_progress_bar=False,
                                 normalize_embeddings=True, convert_to_numpy=True)
        return np.asarray(vecs, dtype=np.float32)


def make_embedder(cfg: ADGRConfig) -> EmbeddingBackend:
    if cfg.embed_backend == "hash_mock":
        return HashMockEmbedding()
    if cfg.embed_backend == "st_local":
        return STLocalEmbedding(cfg.embed)
    raise ValueError(f"embed_backend không hợp lệ: {cfg.embed_backend}")
