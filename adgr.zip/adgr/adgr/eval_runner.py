"""Evaluation runner: chạy QA set qua pipeline, đo retrieval + RAGAS + judge + hiệu năng.

Kết quả giống cấu trúc báo cáo của paper:
- Bảng 3: Hit@K, MRR@K, nDCG@K (gold chunk retrieval)
- Bảng 4 (proxy RAGAS): Faithfulness, Answer Relevancy, Context Recall/Precision
- Bảng 5 (LLM-as-Judge): Comprehensiveness, Diversity, Empowerment, Directness
- Bảng 6 (hiệu năng): input/output tokens, retrieval/generation latency
- Bảng 7: ablation (dense_only / no_anchor / no_edge_filter / no_rerank)
"""
from __future__ import annotations

import time
from pathlib import Path
from typing import Dict, List, Optional

from .config import ADGRConfig
from .generation import generate_answer
from .eval_judge import judge_answer
from .eval_metrics import summarize_runs
from .eval_ragas import ragas_proxy
from .retrieval import ADGRRetriever
from .store import AdgrStore
from .utils import get_logger, read_json, write_json, norm_name, clean_ws

log = get_logger("adgr.eval")

ASSETS = Path(__file__).parent.parent / "assets"


def resolve_gold_chunk(store: AdgrStore, item: dict) -> Optional[str]:
    """Ánh xạ gold_file + gold_section -> chunk_id cụ thể."""
    gold_file = item.get("gold_file", "")
    gold_section = norm_name(item.get("gold_section", ""))
    # tìm doc theo file
    doc = next((d for d in store.documents if d.file_name == gold_file), None)
    if doc is None:
        return None
    doc_chunks = [c for c in store.chunks if c.doc_id == doc.doc_id]
    if not doc_chunks:
        return None
    # 1) khớp section đầu tiên
    if gold_section:
        for c in doc_chunks:
            first_sec = norm_name(c.section_path[0]) if c.section_path else ""
            sec_all = norm_name(" ".join(c.section_path))
            if gold_section and (gold_section in first_sec or first_sec in gold_section
                                 or gold_section in sec_all):
                return c.chunk_id
    # 2) fallback: chunk có độ trùng keyword cao với question
    from .vitoken import tokenize
    qtok = set(tokenize(item["question"], drop_stopwords=True))
    best, best_score = doc_chunks[0], -1
    for c in doc_chunks:
        ctok = set(tokenize(c.content, drop_stopwords=True))
        score = len(qtok & ctok)
        if score > best_score:
            best, best_score = c, score
    return best.chunk_id


def load_qa_set(path: Optional[Path] = None) -> List[dict]:
    path = path or (ASSETS / "qa_eval_sample.json")
    return read_json(path)


def run_eval(store: AdgrStore, cfg: ADGRConfig, retriever: ADGRRetriever,
             embedder, out_path: Path, eval_limit: int = 0,
             with_ablation: bool = False, judge: bool = True) -> dict:
    qa = load_qa_set()
    if eval_limit and eval_limit > 0:
        qa = qa[:eval_limit]
    log.info(f"Evaluation trên {len(qa)} câu hỏi")

    modes = ["full"]
    if with_ablation:
        modes = ["dense_only", "no_anchor", "no_edge_filter", "no_rerank", "full"]
        log.info("Chạy kèm ABLATION: " + ", ".join(modes[:-1]))

    results = {"config": cfg.to_dict(), "n_questions": len(qa), "modes": {}}
    all_items = []

    for mode in modes:
        log.info(f"--- mode = {mode} ---")
        runs: List[dict] = []
        rag_rows: List[dict] = []
        judge_rows: List[dict] = []
        token_stats = {"input_tokens": 0, "output_tokens": 0}
        lat = {"retrieval_ms": 0.0, "generation_ms": 0.0}

        for qi, item in enumerate(qa, 1):
            gold = resolve_gold_chunk(store, item)
            if gold is None:
                log.warning(f"  [{qi}] không resolve được gold chunk cho {item.get('id')}")
                continue

            t0 = time.time()
            chunks, trace = retriever.retrieve(item["question"], use_rerank=(mode != "no_rerank"),
                                               mode=mode)
            lat["retrieval_ms"] += time.time() - t0

            ranked = [c.chunk_id for c in chunks]
            runs.append({"id": item["id"], "ranked_chunks": ranked, "gold_chunk": gold})

            # sinh câu trả lời + metrics
            t0 = time.time()
            gen = generate_answer(retriever.llm, cfg, item["question"], chunks)
            lat["generation_ms"] += time.time() - t0
            token_stats["input_tokens"] += gen.prompt_tokens_est
            token_stats["output_tokens"] += gen.output_tokens_est

            contexts = [c.content for c in chunks]
            try:
                rag = ragas_proxy(retriever.llm, embedder, item["question"], gen.answer,
                                  contexts, item.get("reference_answer", ""))
            except Exception as e:
                log.warning(f"  ragas proxy lỗi: {e}")
                rag = {"faithfulness": 0, "answer_relevancy": 0,
                       "context_precision": 0, "context_recall": 0}
            rag_rows.append(rag)

            jd = {"comprehensiveness": 0, "diversity": 0, "empowerment": 0,
                  "directness": 0, "overall": 0}
            if judge:
                jd = judge_answer(retriever.llm, item["question"], gen.answer,
                                  item.get("reference_answer", ""))
            judge_rows.append(jd)

            all_items.append({
                "mode": mode, "id": item["id"], "question": item["question"],
                "reference_answer": item.get("reference_answer", ""),
                "answer": gen.answer, "gold_chunk": gold,
                "ranked_chunks": ranked, "final_chunks": trace.final_chunks,
                "ragas": rag, "judge": jd,
                "input_tokens_est": gen.prompt_tokens_est,
                "output_tokens_est": gen.output_tokens_est,
                "trace": trace.to_json(),
            })
            if qi % 5 == 0 or qi == len(qa):
                log.info(f"  [{mode}] {qi}/{len(qa)} câu xong")

        # tổng hợp
        retrieval_summary = summarize_runs(runs, ks=cfg.eval.ks, mrr_k=cfg.eval.mrr_k)
        n_rag = max(1, len(rag_rows))
        rag_summary = {k: round(sum(r[k] for r in rag_rows) / n_rag, 4) for k in
                       ("faithfulness", "answer_relevancy", "context_precision", "context_recall")}
        rag_summary["ragas_overall"] = round(sum(rag_summary.values()) / 4, 4)
        n_j = max(1, len(judge_rows))
        judge_summary = {k: round(sum(r[k] for r in judge_rows) / n_j, 4) for k in
                         ("comprehensiveness", "diversity", "empowerment", "directness", "overall")}
        nq = max(1, len(runs))
        eff = {
            "input_tokens_avg": round(token_stats["input_tokens"] / nq, 1),
            "output_tokens_avg": round(token_stats["output_tokens"] / nq, 1),
            "retrieval_latency_ms_avg": round(lat["retrieval_ms"] * 1000 / nq, 1),
            "generation_latency_ms_avg": round(lat["generation_ms"] * 1000 / nq, 1),
        }
        results["modes"][mode] = {
            "retrieval": retrieval_summary,
            "ragas_proxy": rag_summary,
            "llm_judge": judge_summary,
            "efficiency": eff,
            "n_resolved": len(runs),
        }

    # bảng tổng hợp nhanh
    print("\n" + "=" * 78)
    print("TỔNG HỢP EVALUATION (giống Bảng 3-7 của paper)")
    print("=" * 78)
    for mode, res in results["modes"].items():
        print(f"\n[{mode}]")
        print("  Retrieval :", res["retrieval"])
        print("  RAGAS     :", res["ragas_proxy"])
        print("  Judge     :", res["llm_judge"])
        print("  Efficiency:", res["efficiency"])

    write_json({"summary": results, "items": all_items}, out_path)
    log.info(f"Đã lưu kết quả evaluation: {out_path}")
    return results
