"""RAGAS-style evaluation (Section 5.3) bằng LLM judge.

Cach de nhat 4 metric của RAGAS dùng LLM (proxy nhẹ, không cần thư viện RAGAS
nặng dépend của langchain):
- Faithfulness     : tách câu trả lời thành claims; mỗi claim kiểm tra có được
                     hỗ trợ bởi context không -> tỉ lệ được hỗ trợ
- Answer Relevancy : sinh câu hỏi ngược từ câu trả lời, đo cos với câu hỏi gốc
- Context Precision: điểm relevance của từng context chunk với câu hỏi
                     (ground-truth = gold chunk đầu tiên nếu có)
- Context Recall   : từng câu của reference answer có thể quy về context không
"""
from __future__ import annotations

import json
import re
from typing import Dict, List, Optional

import numpy as np

from .embeddings import EmbeddingBackend
from .llm import LLMBackend
from .utils import get_logger

log = get_logger("adgr.ragas")


def _json_of(raw: str) -> Optional[dict]:
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    s, e = raw.find("{"), raw.rfind("}")
    if s >= 0 and e > s:
        try:
            return json.loads(raw[s:e + 1])
        except Exception:
            return None
    return None


# ----------------------------------------------------------------------
def faithfulness(llm: LLMBackend, question: str, answer: str, context: str) -> float:
    """Tỉ lệ claims của câu trả lời được hỗ trợ bởi context."""
    sys_p = ("Bạn là chấm điểm nghiêm ngặt. Tách câu trả lời thành các mệnh đề "
             "thông tin (claim), rồi kiểm tra từng claim có được HỖ TRỢ trực tiếp "
             "bởi ngữ cảnh không. Trả JSON: {\"claims\": [{\"text\": ..., "
             "\"supported\": true|false}], ...}")
    usr = f"NGỮ CẢNH:\n{context[:4000]}\n\nCÂU TRẢ LỜI:\n{answer[:2000]}\n\nJSON:"
    try:
        data = _json_of(llm.chat([{"role": "system", "content": sys_p},
                                  {"role": "user", "content": usr}],
                                 temperature=0.0, max_tokens=1024, json_mode=True))
        claims = data.get("claims", []) if data else []
        if not claims:
            return 0.0
        return sum(1 for c in claims if c.get("supported")) / len(claims)
    except Exception as e:
        log.warning(f"faithfulness lỗi: {e}")
        return 0.0


def answer_relevancy(llm: LLMBackend, embedder: EmbeddingBackend,
                     question: str, answer: str) -> float:
    """Sinh câu hỏi ngược từ câu trả lời rồi đo độ tương đồng cos với câu hỏi."""
    sys_p = ("Sinh 3 câu hỏi mà câu trả lời dưới đây là câu trả lời trực tiếp. "
             "Trả JSON: {\"questions\": [q1, q2, q3]}")
    try:
        data = _json_of(llm.chat([{"role": "system", "content": sys_p},
                                  {"role": "user", "content": answer[:1500]}],
                                 temperature=0.0, max_tokens=512, json_mode=True))
        qs = [q for q in (data or {}).get("questions", []) if q]
        if not qs:
            return 0.0
        zq = embedder.encode([question], is_query=True)
        zg = embedder.encode(qs, is_query=False)
        return float(np.max(zg @ zq[0]))
    except Exception as e:
        log.warning(f"answer_relevancy lỗi: {e}")
        return 0.0


def context_precision(llm: LLMBackend, question: str,
                      contexts: List[str], gold_first: bool = True) -> float:
    """Điểm precision@K trung bình có trọng số theo thứ hạng (RAGAS-style).

    Mỗi context chấm relevant (0/1) so với câu hỏi; nếu có gold chunk thì
    chunk đầu tiên được coi là relevant.
    """
    sys_p = ("Cho mỗi đoạn ngữ cảnh, quyết định nó có RELEVANT với câu hỏi không. "
             "Trả JSON: {\"labels\": [1|0, ...]} theo đúng thứ tự các đoạn.")
    usr = f"CÂU HỎI: {question}\n\n" + "\n\n".join(
        f"--- Đoạn {i+1} ---\n{c[:800]}" for i, c in enumerate(contexts[:10]))
    labels: List[int] = []
    try:
        data = _json_of(llm.chat([{"role": "system", "content": sys_p},
                                  {"role": "user", "content": usr}],
                                 temperature=0.0, max_tokens=256, json_mode=True))
        labels = [1 if int(x) == 1 else 0 for x in (data or {}).get("labels", [])]
    except Exception as e:
        log.warning(f"context_precision lỗi: {e}")
    if gold_first and labels:
        labels[0] = 1
    if not labels:
        return 0.0
    # average precision
    hits, prec = 0, 0.0
    for i, lab in enumerate(labels, 1):
        if lab:
            hits += 1
            prec += hits / i
    return prec / len(labels)


def context_recall(llm: LLMBackend, reference: str, contexts: List[str]) -> float:
    """Từng câu của reference có thể quy về context không."""
    sys_p = ("Cho mỗi câu trong tài liệu tham chiếu, quyết định câu đó có thể "
             "QUY VỀ các đoạn ngữ cảnh đã cho không (thông tin có mặt). "
             "Trả JSON: {\"labels\": [1|0, ...]} theo thứ tự câu.")
    usr = (f"NGỮ CẢNH:\n{chr(10).join(c[:1200] for c in contexts[:8])}\n\n"
           f"REFERENCE:\n{reference[:1500]}\n\nJSON:")
    try:
        data = _json_of(llm.chat([{"role": "system", "content": sys_p},
                                  {"role": "user", "content": usr}],
                                 temperature=0.0, max_tokens=256, json_mode=True))
        labels = (data or {}).get("labels", [])
        if not labels:
            return 0.0
        return sum(1 for x in labels if int(x) == 1) / len(labels)
    except Exception as e:
        log.warning(f"context_recall lỗi: {e}")
        return 0.0


def ragas_proxy(llm: LLMBackend, embedder: EmbeddingBackend,
                question: str, answer: str, contexts: List[str],
                reference: str) -> Dict[str, float]:
    ctx = "\n\n".join(contexts)
    return {
        "faithfulness": round(faithfulness(llm, question, answer, ctx), 4),
        "answer_relevancy": round(answer_relevancy(llm, embedder, question, answer), 4),
        "context_precision": round(context_precision(llm, question, contexts), 4),
        "context_recall": round(context_recall(llm, reference, contexts), 4),
    }
