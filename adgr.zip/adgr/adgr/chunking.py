"""Structure-aware semantic chunking (Section 4.2 của bài báo).

Nguyên tắc đúng paper:
- Giữ nguyên tiêu đề bài + heading phân cấp (##, ###) làm ranh giới ngữ nghĩa
- Chunk bám theo section trong cây heading; section quá dài được chia đệ quy
  theo đoạn văn (paragraph) nhưng vẫn giữ metadata phân cấp của section cha
- Mỗi chunk gắn tiêu đề bài, đường dẫn section cha và SOURCE URL (truy vết bằng chứng)
"""
from __future__ import annotations

import re
from typing import List

from .corpus import Chunk, Document
from .utils import estimate_tokens, sha1

HEADING_RE = re.compile(r"^(#{2,4})\s+(.+?)\s*$")


def _split_paragraphs(text: str) -> List[str]:
    parts = re.split(r"\n\s*\n", text)
    return [p.strip() for p in parts if p and p.strip()]


def _pack_paragraphs(paras: List[str], max_chars: int) -> List[str]:
    """Gộp các đoạn liên tiếp thành nhóm <= max_chars (đệ quy thay cho tách cứng)."""
    groups: List[List[str]] = []
    cur: List[str] = []
    cur_len = 0
    for p in paras:
        plen = len(p)
        if plen > max_chars:
            # chia tiếp theo câu nếu 1 đoạn vẫn quá dài
            sentences = re.split(r"(?<=[.!?])\s+", p)
            for s in sentences:
                if cur and cur_len + len(s) + 1 > max_chars:
                    groups.append(cur)
                    cur, cur_len = [], 0
                cur.append(s)
                cur_len += len(s) + 1
            continue
        if cur and cur_len + plen + 2 > max_chars:
            groups.append(cur)
            cur, cur_len = [], 0
        cur.append(p)
        cur_len += plen + 2
    if cur:
        groups.append(cur)
    return ["\n\n".join(g) for g in groups if g]


def chunk_document(doc: Document, max_chunk_chars: int = 1000,
                   min_chunk_chars: int = 120) -> List[Chunk]:
    """Tách 1 document thành các chunk bám cấu trúc section."""
    lines = doc.text.split("\n")
    # [section_path, content_lines]
    sections: List[tuple[List[str], List[str]]] = [([], [])]
    for line in lines:
        m = HEADING_RE.match(line.strip())
        if m:
            level = len(m.group(1))
            heading = m.group(2).strip()
            # cắt về đúng độ sâu: giữ (level-2) phần tử đầu
            base = sections[0][0] if not sections[-1][0] else sections[-1][0]
            # xây path mới: đường dẫn hiện tại cắt theo level
            cur_path = sections[-1][0]
            # path của heading cấp 2 là [heading]; cấp 3 là [path2, heading]...
            new_path = cur_path[: max(0, level - 2)] + [heading]
            sections.append((new_path, []))
        else:
            sections[-1][1].append(line)

    chunks: List[Chunk] = []
    for path, content_lines in sections:
        content = "\n".join(content_lines).strip()
        if not content:
            continue
        paras = _split_paragraphs(content)
        pieces = _pack_paragraphs(paras, max_chunk_chars)
        # nếu section chỉ gồm 1 heading gộp với đoạn ngắn -> vẫn ok
        for i, piece in enumerate(pieces):
            if len(piece) < min_chunk_chars and pieces:
                # gộp piece quá ngắn vào piece trước nếu cùng section
                if chunks and chunks[-1].section_path == path and len(chunks[-1].content) + len(piece) < max_chunk_chars * 1.5:
                    prev = chunks.pop()
                    piece = prev.content + "\n\n" + piece
            sub_path = path if len(pieces) == 1 else path + [f"(phần {i + 1}/{len(pieces)})"]
            section_str = " > ".join(path) if path else "Giới thiệu"
            breadcrumb = f"{doc.title} > {section_str}"
            embed_text = f"{doc.title} | {section_str}\n{piece}"
            chunk_id = sha1(doc.doc_id + "|" + "|".join(sub_path) + "|" + piece[:120])
            chunks.append(Chunk(
                chunk_id=chunk_id,
                doc_id=doc.doc_id,
                doc_title=doc.title,
                section_path=sub_path,
                content=piece,
                embed_text=embed_text,
                source_url=doc.url,
                n_tokens_est=estimate_tokens(piece),
            ))
    return chunks


def chunk_corpus(docs: List[Document], max_chunk_chars: int = 1000,
                 min_chunk_chars: int = 120) -> List[Chunk]:
    all_chunks: List[Chunk] = []
    for d in docs:
        all_chunks.extend(chunk_document(d, max_chunk_chars, min_chunk_chars))
    return all_chunks
