"""LLM backends pluggable cho ADGR.

Các backend:
- mock         : deterministic, KHÔNG cần GPU/API — dùng để test pipeline (mặc định)
- openai_compat: bất kỳ endpoint OpenAI-compatible nào (vLLM serve, Ollama,
                 OpenRouter, ...) — cấu hình qua base_url/api_key/model
- vllm_local   : vLLM chạy trong tiến trình (Kaggle GPU, đúng model paper
                 Qwen/Qwen2.5-14B-Instruct-AWQ)
- zai          : z-ai-web-dev-sdk qua node subprocess (chạy trong sandbox tích hợp)

Mọi backend đều hiện thực interface `chat(messages, temperature, max_tokens) -> str`.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from abc import ABC, abstractmethod
from pathlib import Path
from typing import List, Dict, Optional

from .config import ADGRConfig, LLMConfig
from .utils import get_logger
from .vitoken import tokenize, keywords_heuristic

log = get_logger("adgr.llm")

Message = Dict[str, str]  # {"role": "system"|"user"|"assistant", "content": str}


class LLMBackend(ABC):
    name = "base"

    @abstractmethod
    def chat(self, messages: List[Message], temperature: float = 0.0,
             max_tokens: int = 2048, json_mode: bool = False) -> str:
        raise NotImplementedError

    def close(self) -> None:  # optional
        pass


# =====================================================================
# Mock - deterministic
# =====================================================================
class MockLLM(LLMBackend):
    """LLM giả lập deterministic để chạy pipeline không cần model.

    - Keyword extraction: heuristic tokenize tiếng Việt (Kl/Kh)
    - KG extraction: heuristic gazetteer + co-occurrence trong chunk
    - Generation: trích câu chứa keyword từ ngữ cảnh
    """

    name = "mock"

    SYMPTOM_HINTS = ("đau", "sốt", "ho", "chóng mặt", "buồn nôn", "nôn", "phù",
                     "mẩn", "ngứa", "tiêu chảy", "táo bón", "khó thở", "mệt mỏi",
                     "đau đầu", "run", "co giật", "khát", "sụt cân", "chán ăn")
    DISEASE_HINTS = ("bệnh", "viêm", "hội chứng", "suy", "tăng huyết áp",
                     "đái tháo đường", "ung thư", "dị ứng", "nhiễm", "lão hóa",
                     "loãng xương", "thiếu", "quá mẫn", "hen")

    def chat(self, messages: List[Message], temperature: float = 0.0,
             max_tokens: int = 2048, json_mode: bool = False) -> str:
        user = "\n".join(m["content"] for m in messages if m["role"] == "user")
        sysc = "\n".join(m["content"] for m in messages if m["role"] == "system").lower()
        task = self._detect_task(messages, user)
        if task == "keywords":
            return self._keywords(user)
        if task == "extract":
            return self._extract(user)
        if task == "judge":
            return self._judge(sysc, user)
        return self._generate(messages, user)

    # ---- task detection qua system prompt ----
    def _detect_task(self, messages: List[Message], user: str = "") -> str:
        sysc = "\n".join(m["content"] for m in messages if m["role"] == "system").lower()
        if "trích xuất keyword" in sysc or ("keyword" in sysc and "json" in sysc):
            return "keywords"
        if "knowledge graph specialist" in sysc or "trích xuất thực thể" in sysc:
            return "extract"
        if any(k in sysc for k in ("chấm điểm", "judge", "đánh giá", "relevan",
                                   "quy về", "claim", "sinh 3 câu hỏi", "câu hỏi ngược")):
            return "judge"
        return "generate"

    # ---- keywords ----
    def _keywords(self, user: str) -> str:
        # user format: "CÂU HỎI: <q>\n\nJSON:" - cắt bỏ phần đuôi JSON:
        q = user
        m = re.search(r"CÂU HỎI:\s*(.+?)(?:\n\s*JSON:|\Z)", user, re.DOTALL)
        if m:
            q = m.group(1)
        toks = keywords_heuristic(q, max_kw=10)
        low = [t for t in toks if len(t) >= 3][:6]
        high = [t for t in toks if len(t) >= 4][:4] or low[:2]
        return json.dumps({"low_level": low, "high_level": high}, ensure_ascii=False)

    # ---- KG extraction (heuristic gazetteer) ----
    _DRUG_PAT = re.compile(
        r"\b([A-Z][A-Za-z0-9]+(?:\s(?:[A-Z][A-Za-z0-9]+|\d+\s?mg))*)\b")
    _KNOWN_DRUGS = ("paracetamol", "ambroxol", "ibuprofen", "vildagliptin", "metformin",
                    "aescin", "ascorbic", "desloratadin", "domperidon", "zinc",
                    "acyclovir", "amoxicillin", "omeprazole", "artichaut", "actiso",
                    "calci", "vitamin", "aspirin", "bismuth", "cephalexin", "cetebe",
                    "dexamethason", "diphenhydramin", "doxycyclin")

    def _extract(self, user: str) -> str:
        text = user
        m = re.search(r"VĂN BẢN:\s*(.+)", user, re.DOTALL)
        if m:
            text = m.group(1)
        text_low = text.lower()
        ents: Dict[str, Dict] = {}

        def add(name: str, etype: str, desc: str) -> None:
            name = name.strip()
            if not name or len(name) < 3:
                return
            key = name.lower()
            if key not in ents:
                ents[key] = {"name": name, "type": etype, "description": desc}

        # 1) thuốc/gợi ý từ gazetteer
        for d in self._KNOWN_DRUGS:
            if d in text_low:
                add(d.capitalize(), "Drug", f"Hoạt chất/thuốc {d} được nhắc tới trong văn bản.")

        # 2) triệu chứng & bệnh theo hint
        for h in self.SYMPTOM_HINTS:
            if h in text_low:
                add(h.capitalize(), "Symptom", f"Triệu chứng '{h}' xuất hiện trong ngữ cảnh.")
        for h in self.DISEASE_HINTS:
            if h in text_low and h not in self.SYMPTOM_HINTS:
                add(h.capitalize(), "Disease", f"Bệnh/tình trạng '{h}' được nhắc tới trong ngữ cảnh.")

        # 3) cấu trúc đề mục thuốc YouMed: "chỉ định", "chống chỉ định", "tác dụng phụ"
        sections = re.findall(r"##\s*(.+)", text)
        for s in sections[:6]:
            s_clean = s.strip()
            if "chống chỉ định" in s_clean.lower():
                add("Chống chỉ định", "Treatment method", "Hạn chế/chống chỉ định khi sử dụng thuốc.")
            elif "chỉ định" in s_clean.lower():
                add("Chỉ định", "Treatment method", "Chỉ định điều trị của thuốc/bài viết.")
            elif "tác dụng phụ" in s_clean.lower():
                add("Tác dụng phụ", "Symptom", "Các tác dụng không mong muốn có thể gặp.")
            elif "liều" in s_clean.lower():
                add("Liều dùng", "Treatment method", "Hướng dẫn liều lượng sử dụng.")

        ent_list = list(ents.values())[:20]

        # relations: ghép cặp co-occurring giữa Drug và loại khác trong cùng chunk
        rels: List[Dict] = []
        drugs = [e for e in ent_list if e["type"] == "Drug"]
        others = [e for e in ent_list if e["type"] != "Drug"]
        for d in drugs:
            for o in others:
                kw = "điều trị" if o["type"] in ("Disease", "Symptom") else "liên quan"
                rels.append({
                    "source": d["name"], "target": o["name"], "keywords": kw,
                    "description": f"{d['name']} {kw} với {o['name']} theo nội dung chunk.",
                })
                if len(rels) >= 20:
                    break
            if len(rels) >= 20:
                break

        lines = [f"entity<|#|>{e['name']}<|#|>{e['type']}<|#|>{e['description']}" for e in ent_list]
        lines += [f"relation<|#|>{r['source']}<|#|>{r['target']}<|#|>{r['keywords']}<|#|>{r['description']}" for r in rels]
        lines.append("<|COMPLETE|>")
        return "\n".join(lines)

    # ---- judge (mock): trả đúng schema từng loại prompt ----
    def _judge(self, sysc: str, user: str) -> str:
        # 1) claims (faithfulness)
        if "claim" in sysc:
            am = re.search(r"CÂU TRẢ LỜI:\s*(.+)", user, re.DOTALL)
            ans = am.group(1)[:2500] if am else ""
            sents = [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n+", ans) if len(s.strip()) > 15][:10]
            claims = [{"text": s, "supported": True} for s in sents]
            return json.dumps({"claims": claims}, ensure_ascii=False)
        # 2) labels (context_precision: "--- Đoạn i" | context_recall: câu REFERENCE)
        if "label" in sysc or "đoạn ngữ cảnh" in sysc or "quy về" in sysc:
            n_seg = len(re.findall(r"--- Đoạn", user))
            if n_seg == 0:
                rm = re.search(r"REFERENCE:\s*(.+)", user, re.DOTALL)
                ref = rm.group(1) if rm else ""
                n_seg = max(1, len([s for s in re.split(r"(?<=[.!?])\s+", ref) if len(s.strip()) > 15]))
            return json.dumps({"labels": [1] * n_seg}, ensure_ascii=False)
        # 3) questions ngược (answer relevancy)
        if "sinh 3 câu hỏi" in sysc or "câu hỏi ngược" in sysc:
            body = user[:2000]
            kws = keywords_heuristic(body, max_kw=3) or ["y tế"]
            qs = [f"Cách dùng và tác dụng của {k} như thế nào?" for k in kws]
            return json.dumps({"questions": qs[:3]}, ensure_ascii=False)
        # 4) LLM-as-Judge 4 chiều
        return json.dumps({
            "comprehensiveness": 0.8, "diversity": 0.8,
            "empowerment": 0.8, "directness": 0.8, "overall": 0.8,
        }, ensure_ascii=False)

    # ---- generation: trích câu chứa keyword ----
    def _generate(self, messages: List[Message], user: str) -> str:
        sysc = "\n".join(m["content"] for m in messages if m["role"] == "system")
        um = re.search(r"NGỮ CẢNH:\s*(.+?)(?:\nCÂU HỎI:|$)", user, re.DOTALL)
        qm = re.search(r"CÂU HỎI:\s*(.+)", user, re.DOTALL)
        ctx = um.group(1) if um else ""
        q = qm.group(1).strip() if qm else user[-200:]
        if not ctx.strip():
            return "Không tìm thấy thông tin trong tài liệu (ngữ cảnh trống)."
        kws = [t for t in keywords_heuristic(q, max_kw=6)]
        sents = re.split(r"(?<=[.!?])\s+|\n+", ctx)
        scored = []
        for s in sents:
            s_clean = s.strip()
            if len(s_clean) < 25:
                continue
            sl = s_clean.lower()
            score = sum(1 for k in kws if k in sl or k.replace("_", " ") in sl)
            if score:
                scored.append((score, s_clean))
        scored.sort(key=lambda x: -x[0])
        picked = [s for _, s in scored[:6]]
        if not picked:
            return "Không tìm thấy thông tin liên quan trong ngữ cảnh được cung cấp."
        return "[MOCK] Dựa trên tài liệu:\n- " + "\n- ".join(picked)


# =====================================================================
# OpenAI-compatible (vLLM serve / Ollama / OpenRouter / ...)
# =====================================================================
class OpenAICompatLLM(LLMBackend):
    name = "openai_compat"

    def __init__(self, cfg: LLMConfig):
        self.cfg = cfg
        self.session = None
        try:
            import requests
            self.session = requests.Session()
        except ImportError as e:
            raise ImportError("openai_compat cần 'requests'") from e

    def chat(self, messages: List[Message], temperature: float = 0.0,
             max_tokens: int = 2048, json_mode: bool = False) -> str:
        url = self.cfg.base_url.rstrip("/") + "/chat/completions"
        payload = {
            "model": self.cfg.model,
            "messages": messages,
            "temperature": temperature,
            "top_p": self.cfg.top_p,
            "max_tokens": max_tokens,
        }
        if json_mode:
            payload["response_format"] = {"type": "json_object"}
        headers = {"Content-Type": "application/json"}
        if self.cfg.api_key and self.cfg.api_key != "EMPTY":
            headers["Authorization"] = f"Bearer {self.cfg.api_key}"
        r = self.session.post(url, json=payload, headers=headers,
                              timeout=self.cfg.request_timeout)
        r.raise_for_status()
        data = r.json()
        return data["choices"][0]["message"]["content"]


# =====================================================================
# vLLM in-process (Kaggle GPU)
# =====================================================================
class VllmLocalLLM(LLMBackend):
    name = "vllm_local"

    def __init__(self, cfg: LLMConfig):
        try:
            from vllm import LLM, SamplingParams
            from transformers import AutoTokenizer
        except ImportError as e:
            raise ImportError(
                "vllm_local cần 'vllm' và 'transformers': pip install vllm transformers"
            ) from e
        log.info(f"[llm] Khởi tạo vLLM in-process: {cfg.model}")
        self.tok = AutoTokenizer.from_pretrained(cfg.model)
        self.llm = LLM(
            model=cfg.model,
            gpu_memory_utilization=cfg.vllm_gpu_memory_utilization,
            max_model_len=cfg.vllm_max_model_len,
            trust_remote_code=True,
        )
        self._SamplingParams = SamplingParams

    def chat(self, messages: List[Message], temperature: float = 0.0,
             max_tokens: int = 2048, json_mode: bool = False) -> str:
        prompt = self.tok.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True)
        sp = self._SamplingParams(temperature=temperature, top_p=1.0,
                                  max_tokens=max_tokens)
        outs = self.llm.generate([prompt], sp)
        return outs[0].outputs[0].text

    def close(self) -> None:
        try:
            del self.llm
            import torch, gc
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except Exception:
            pass


# =====================================================================
# ZAI (z-ai-web-dev-sdk qua node subprocess)
# =====================================================================
_BRIDGE = Path(__file__).parent / "zai_bridge.mjs"


class ZaiLLM(LLMBackend):
    """Gọi z-ai-web-dev-sdk (Node) qua subprocess. Hoạt động trong môi trường
    tích hợp sẵn SDK; trên Kaggle sẽ tự lỗi -> hãy dùng vllm_local/openai_compat."""

    name = "zai"

    def __init__(self, cfg: LLMConfig):
        if not _BRIDGE.exists():
            raise RuntimeError("Thiếu adgr/zai_bridge.mjs")
        self.cfg = cfg
        # smoke test
        r = subprocess.run([sys.executable, "-c", "import shutil;print(shutil.which('node') or '')"],
                           capture_output=True, text=True)
        self.node = r.stdout.strip() or "node"

    def chat(self, messages: List[Message], temperature: float = 0.0,
             max_tokens: int = 2048, json_mode: bool = False) -> str:
        payload = json.dumps({"messages": messages, "temperature": temperature,
                              "max_tokens": max_tokens}, ensure_ascii=False)
        proc = subprocess.run(
            [self.node, str(_BRIDGE)],
            input=payload.encode("utf-8"), capture_output=True, timeout=300)
        if proc.returncode != 0:
            raise RuntimeError(f"zai_bridge lỗi: {proc.stderr.decode()[:500]}")
        out = json.loads(proc.stdout.decode("utf-8"))
        if not out.get("ok"):
            raise RuntimeError(f"zai_bridge lỗi: {out.get('error')}")
        return out["content"]


# =====================================================================
# Factory
# =====================================================================
def make_llm(cfg: ADGRConfig) -> LLMBackend:
    kind = cfg.llm_backend
    if kind == "mock":
        return MockLLM()
    if kind == "openai_compat":
        return OpenAICompatLLM(cfg.llm)
    if kind == "vllm_local":
        return VllmLocalLLM(cfg.llm)
    if kind == "zai":
        return ZaiLLM(cfg.llm)
    raise ValueError(f"llm_backend không hợp lệ: {kind}")
