"""Vector index cosine thuần numpy — theo tinh thần NanoVectorDB của paper.

Lưu/đọc: .npz (vectors) + .json (ids). Mọi vector đã L2-norm nên dot = cosine.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable, List, Optional, Sequence, Tuple

import numpy as np

from .utils import ensure_dir, l2norm


class NumpyVectorIndex:
    def __init__(self, dim: int):
        self.dim = int(dim)
        self.ids: List[str] = []
        self.id_pos: dict = {}
        self.vecs = np.zeros((0, self.dim), dtype=np.float32)

    def __len__(self) -> int:
        return len(self.ids)

    def add(self, ids: Sequence[str], vecs: np.ndarray) -> None:
        """Thêm (hoặc cập nhật) các vector đã L2-norm."""
        vecs = np.asarray(vecs, dtype=np.float32)
        if vecs.ndim == 1:
            vecs = vecs[None, :]
        if vecs.shape[0] != len(ids):
            raise ValueError(f"ids vs vecs mismatch: {len(ids)} != {vecs.shape[0]}")
        vecs = l2norm(vecs)
        new_ids, new_vecs = [], []
        for i, iid in enumerate(ids):
            if iid in self.id_pos:
                self.vecs[self.id_pos[iid]] = vecs[i]  # update
            else:
                new_ids.append(iid)
                new_vecs.append(vecs[i])
        if new_ids:
            self.vecs = np.vstack([self.vecs, np.asarray(new_vecs, dtype=np.float32)])
            for i, iid in enumerate(new_ids):
                self.id_pos[iid] = len(self.ids)
                self.ids.append(iid)

    def search(self, qvec: np.ndarray, top_k: int = 10,
               threshold: Optional[float] = None,
               exclude_ids: Optional[set] = None) -> List[Tuple[str, float]]:
        """Trả [(id, cos)] giảm dần; lọc ngưỡng + loại trừ id."""
        if not self.ids:
            return []
        q = l2norm(np.asarray(qvec, dtype=np.float32).ravel())
        sims = self.vecs @ q
        order = np.argsort(-sims)
        out: List[Tuple[str, float]] = []
        for idx in order:
            idx = int(idx)
            iid = self.ids[idx]
            s = float(sims[idx])
            if threshold is not None and s < threshold:
                break
            if exclude_ids and iid in exclude_ids:
                continue
            out.append((iid, s))
            if len(out) >= top_k:
                break
        return out

    def save(self, path: str | Path) -> None:
        path = Path(path)
        ensure_dir(path.parent)
        np.savez(str(path.with_suffix(".npz")), vecs=self.vecs)
        meta = {"dim": self.dim, "ids": self.ids}
        path.with_suffix(".json").write_text(
            json.dumps(meta, ensure_ascii=False), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "NumpyVectorIndex":
        path = Path(path)
        meta = json.loads(path.with_suffix(".json").read_text(encoding="utf-8"))
        idx = cls(dim=meta["dim"])
        idx.ids = meta["ids"]
        idx.id_pos = {iid: i for i, iid in enumerate(idx.ids)}
        data = np.load(str(path.with_suffix(".npz")))
        idx.vecs = data["vecs"].astype(np.float32)
        return idx
