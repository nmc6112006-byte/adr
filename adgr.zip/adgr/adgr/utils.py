"""Tiện ích chung: logging, ước lượng token, IO JSON, chuỗi Helpers."""
from __future__ import annotations

import json
import logging
import os
import re
import sys
import unicodedata
from pathlib import Path
from typing import Any

import numpy as np


def get_logger(name: str = "adgr", verbose: bool = True) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s %(name)s: %(message)s", "%H:%M:%S"))
        logger.addHandler(handler)
        logger.propagate = False
    logger.setLevel(logging.INFO if verbose else logging.WARNING)
    return logger


# ---------------- token estimate ----------------
# Tieng Viet ~ 1 token / 3.2 ky tu voi tokenizer Qwen; dung uoc luong budget L_max.
_CHARS_PER_TOKEN = 3.2


def estimate_tokens(text: str) -> int:
    if not text:
        return 0
    return max(1, int(len(text) / _CHARS_PER_TOKEN))


# ---------------- IO ----------------
def read_json(path: str | Path) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(obj: Any, path: str | Path, ensure_ascii: bool = False) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=ensure_ascii, indent=1)
    tmp.replace(path)


def write_jsonl(items: list, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for it in items:
            f.write(json.dumps(it, ensure_ascii=False) + "\n")


def read_jsonl(path: str | Path) -> list:
    out = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                out.append(json.loads(line))
    return out


def sha1(text: str) -> str:
    import hashlib
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:12]


def set_seed(seed: int) -> None:
    import random
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
    except Exception:
        pass


# ---------------- text helpers ----------------
_WS_RE = re.compile(r"\s+")


def clean_ws(text: str) -> str:
    return _WS_RE.sub(" ", text).strip()


def norm_name(name: str) -> str:
    """Chuẩn hoá tên thực thể để merge: bỏ khoảng trắng thừa, lowercase,
    giữ nguyên dấu (tên thuốc/bệnh tiếng Việt phân biệt theo dấu)."""
    t = clean_ws(name).lower()
    t = t.strip(" .,:;!?-–—()[]{}\"'")
    return t


def strip_accents(text: str) -> str:
    return "".join(ch for ch in unicodedata.normalize("NFD", text)
                   if unicodedata.category(ch) != "Mn")


def batched(iterable, n: int):
    """Chia nhỏ list thành các batch độ dài n."""
    it = list(iterable)
    for i in range(0, len(it), n):
        yield it[i:i + n]


def l2norm(mat: np.ndarray) -> np.ndarray:
    if mat.ndim == 1:
        n = np.linalg.norm(mat)
        return mat / (n + 1e-12)
    norms = np.linalg.norm(mat, axis=1, keepdims=True)
    return mat / (norms + 1e-12)


def cosine_topk(qvec: np.ndarray, mat: np.ndarray, top_k: int,
                threshold: float | None = None,
                exclude: set | None = None):
    """Trả về [(row_idx, cos)] giảm dần, lọc theo threshold và exclude."""
    if mat.shape[0] == 0:
        return []
    q = l2norm(qvec.astype(np.float32))
    m = l2norm(mat.astype(np.float32))
    sims = m @ q
    order = np.argsort(-sims)
    out = []
    for idx in order:
        idx = int(idx)
        s = float(sims[idx])
        if threshold is not None and s < threshold:
            break
        if exclude is not None and idx in exclude:
            continue
        out.append((idx, s))
        if len(out) >= top_k:
            break
    return out


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def gpu_free_mb() -> int:
    """MB GPU rảnh; -1 nếu không có GPU."""
    try:
        import torch
        if torch.cuda.is_available():
            free, _total = torch.cuda.mem_get_info(0)
            return int(free / (1024 * 1024))
    except Exception:
        pass
    return -1
