"""Orchestrator các bước build: corpus -> chunks -> KG -> indices.

CLI tương ứng:
  adgr build-corpus  (tải corpus + chunking)
  adgr build-kg      (trích xuất KG bằng LLM cho từng chunk)
  adgr build-index   (embed + BM25 index toàn bộ)
"""
from __future__ import annotations

import time
from pathlib import Path
from typing import List, Optional

from .config import ADGRConfig
from .corpus import Chunk, Document, load_corpus
from .chunking import chunk_corpus
from .embeddings import EmbeddingBackend, make_embedder
from .index_vec import NumpyVectorIndex
from .kg_graph import KnowledgeGraph
from .kg_extract import extract_chunk_graph
from .llm import LLMBackend, make_llm
from .store import AdgrStore
from .utils import get_logger

log = get_logger("adgr.build")


# ----------------------------------------------------------------------
def build_corpus_stage(cfg: ADGRConfig, data_dir: Path) -> List[Chunk]:
    log.info("=== [1/3] BUILD CORPUS + CHUNKING ===")
    docs: List[Document] = load_corpus(
        source=cfg.corpus.source, hf_dataset=cfg.corpus.hf_dataset,
        hf_limit=cfg.corpus.hf_limit, upload_dir=cfg.corpus.upload_dir)
    if not docs:
        raise RuntimeError("Corpus rỗng - kiểm tra nguồn dữ liệu.")
    chunks = chunk_corpus(docs, cfg.corpus.max_chunk_chars, cfg.corpus.min_chunk_chars)
    store = AdgrStore(data_dir)
    store.documents = docs
    store.chunks = chunks
    store.chunk_by_id = {c.chunk_id: c for c in chunks}
    store.meta = {"stage": "corpus", "n_docs": len(docs), "n_chunks": len(chunks)}
    store.save_corpus()
    store.save_meta()
    log.info(f"Corpus: {len(docs)} documents -> {len(chunks)} chunks "
             f"(trung bình {len(chunks)/len(docs):.1f} chunks/doc)")
    return chunks


# ----------------------------------------------------------------------
def build_kg_stage(cfg: ADGRConfig, data_dir: Path,
                   llm: Optional[LLMBackend] = None) -> KnowledgeGraph:
    """Trích xuất KG bằng LLM — 1 lần duy nhất cho từng chunk, gắn source
    chunk ngay trong vòng lặp (đúng Section 4.3: mỗi entity/relation lưu
    identifier của chunk gốc)."""
    log.info("=== [2/3] BUILD KNOWLEDGE GRAPH (LLM extraction, temperature=0) ===")
    store = AdgrStore(data_dir).load_corpus()
    chunks = store.chunks
    if cfg.kg.max_chunks_per_run and cfg.kg.max_chunks_per_run > 0:
        chunks = chunks[: cfg.kg.max_chunks_per_run]
        log.info(f"Giới hạn trích xuất: {len(chunks)}/{len(store.chunks)} chunks")

    if llm is None:
        llm = make_llm(cfg)

    kg = KnowledgeGraph()
    t0 = time.time()
    n_err = 0
    for i, ch in enumerate(chunks, 1):
        try:
            ext = extract_chunk_graph(llm, cfg, ch.chunk_id, ch.embed_text)
        except Exception as e:
            n_err += 1
            if n_err <= 3:
                log.warning(f"  chunk {i} trích xuất lỗi, bỏ qua: {e}")
            continue

        # 1) thêm entity, gắn source chunk ngay
        name_to_id = {}
        for e in ext.entities:
            ent_id = kg._ensure_entity(e.name, e.type, e.description)
            name_to_id[e.name.strip().lower()] = ent_id
            kg.entities[ent_id].source_chunk_ids.add(ch.chunk_id)
        # 2) thêm relation, gắn source chunk
        for r in ext.relations:
            sid = name_to_id.get(r.source.strip().lower())
            tid = name_to_id.get(r.target.strip().lower())
            if not sid:
                sid = kg._name_index.get(r.source.strip().lower())
            if not tid:
                tid = kg._name_index.get(r.target.strip().lower())
            if not sid or not tid or sid == tid:
                continue
            rel_id = kg._ensure_relation(sid, tid, r.keywords, r.description, ch.chunk_id)
            kg.relations[rel_id].source_chunk_ids.add(ch.chunk_id)

        if i % 25 == 0 or i == len(chunks):
            log.info(f"  {i}/{len(chunks)} chunks | entities={len(kg.entities)} "
                     f"relations={len(kg.relations)} | {time.time()-t0:.0f}s")

    kg.save(store.kg_dir)
    st = kg.stats()
    log.info(f"KG stats: {st}")
    log.info(f"Lưu KG vào {store.kg_dir}")
    if n_err:
        log.warning(f"Số chunk trích xuất lỗi đã bỏ qua: {n_err}")
    return kg


# ----------------------------------------------------------------------
def build_index_stage(cfg: ADGRConfig, data_dir: Path,
                      embedder: Optional[EmbeddingBackend] = None) -> None:
    log.info("=== [3/3] BUILD INDICES (BM25 + dense) ===")
    store = AdgrStore(data_dir).load_corpus().load_kg()
    if embedder is None:
        embedder = make_embedder(cfg)
    t0 = time.time()

    # --- BM25 entity index: name + description (đúng Bảng 2) ---
    ent_ids, ent_texts = [], []
    for e in store.kg.entities.values():
        ent_ids.append(e.id)
        ent_texts.append(f"{e.name} {e.description}")
    store.bm25_entity.build(ent_ids, ent_texts)
    log.info(f"  BM25 entity: {len(ent_ids)} docs | {time.time()-t0:.1f}s")

    # --- BM25 chunk index ---
    t1 = time.time()
    store.bm25_chunk.build([c.chunk_id for c in store.chunks],
                           [c.embed_text for c in store.chunks])
    log.info(f"  BM25 chunk: {len(store.chunks)} docs | {time.time()-t1:.1f}s")

    # --- Dense: entity NAME (Eq.4 dùng embedding tên entity) ---
    t2 = time.time()
    name_vecs = embedder.encode([store.kg.entities[eid].name for eid in ent_ids],
                                is_query=False)
    ve = NumpyVectorIndex(dim=embedder.dim)
    ve.add(ent_ids, name_vecs)
    store.vec_entity = ve
    log.info(f"  Dense entity names: {len(ve)} vecs dim={ve.dim} | {time.time()-t2:.1f}s")

    # --- Dense: edge text (keywords + source + target + description) ---
    t3 = time.time()
    rel_ids, rel_texts = [], []
    for r in store.kg.relations.values():
        rel_ids.append(r.id)
        rel_texts.append(store.kg.entity_edge_text(r))
    vr = NumpyVectorIndex(dim=embedder.dim)
    if rel_ids:
        vr.add(rel_ids, embedder.encode(rel_texts, is_query=False))
    store.vec_relation = vr
    log.info(f"  Dense relations: {len(vr)} vecs | {time.time()-t3:.1f}s")

    # --- Dense: chunks (Eq.15) ---
    t4 = time.time()
    vc = NumpyVectorIndex(dim=embedder.dim)
    if store.chunks:
        vc.add([c.chunk_id for c in store.chunks],
               embedder.encode([c.embed_text for c in store.chunks], is_query=False))
    store.vec_chunk = vc
    log.info(f"  Dense chunks: {len(vc)} vecs | {time.time()-t4:.1f}s")

    store.meta = {"stage": "index", "embed_backend": cfg.embed_backend,
                  "embed_model": cfg.embed.model if cfg.embed_backend == "st_local" else "hash_mock_512d",
                  "n_entities": len(ent_ids), "n_relations": len(rel_ids),
                  "n_chunks": len(store.chunks)}
    store.save_all()
    log.info(f"Đã lưu indices vào {data_dir/'index'}")
