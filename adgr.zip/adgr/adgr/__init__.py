"""ADGR - Adaptive Directed Graph Retrieval for Graph-based RAG.

Tái hiện (re-implementation) framework ADGR từ bài báo:
"Adaptive Directed Graph Retrieval for Graph-Based Retrieval-Augmented
Generation" (Nguyen-Tien et al., Applied Intelligence) trên tài nguyên
ViMedGraph (corpus YouMed tiếng Việt, HF: vuduylinh150804/vietmed-crawled-corpus).
"""

__version__ = "1.0.0"
