"""Corpus: mô hình Document/Chunk + các nguồn dữ liệu.

Nguồn dữ liệu (Section 4.1 của bài báo):
- sample      : 44 bài YouMed thật đi kèm repo (lấy từ HF dataset chính thức)
- huggingface : tải corpus đầy đủ từ vuduylinh150804/vietmed-crawled-corpus
- dir         : thư mục .txt/.md do người dùng upload (mỗi file 1 bài, có/không có
                dòng "# SOURCE_URL:" đầu file)
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import List, Optional

from .utils import sha1, ensure_dir, get_logger

log = get_logger("adgr.corpus")

ASSET_SAMPLE_DIR = Path(__file__).parent.parent / "assets" / "sample_corpus"

SOURCE_URL_RE = re.compile(r"^#\s*SOURCE_URL:\s*(\S+)", re.MULTILINE)


@dataclass
class Document:
    doc_id: str
    title: str
    url: str
    text: str                     # toàn văn markdown-like (đã bỏ dòng SOURCE_URL)
    file_name: str = ""

    def short(self) -> dict:
        return {"doc_id": self.doc_id, "title": self.title, "url": self.url,
                "file_name": self.file_name, "chars": len(self.text)}


@dataclass
class Chunk:
    chunk_id: str
    doc_id: str
    doc_title: str
    section_path: List[str]       # breadcrumb heading, vd ["Thành phần", "Công dụng"]
    content: str                  # nội dung sạch
    embed_text: str               # breadcrumb + content (dùng để embed/BM25)
    source_url: str = ""
    n_tokens_est: int = 0

    def to_dict(self) -> dict:
        return asdict(self)


# ------------------------------------------------------------------
# Parsing YouMed-like document
# ------------------------------------------------------------------
def parse_document(raw: str, file_name: str = "") -> Document:
    """Parse 1 file .txt YouMed: dòng '# SOURCE_URL: <url>' + markdown '#title'."""
    url = ""
    m = SOURCE_URL_RE.search(raw)
    if m:
        url = m.group(1).strip()
        raw = raw[m.end():].lstrip("\n")

    title = file_name.replace(".txt", "").replace(".md", "").replace("-", " ")
    tm = re.search(r"^\s*#\s+(.+?)\s*$", raw, re.MULTILINE)
    if tm:
        title = tm.group(1).strip()
        raw = raw[:tm.start()] + "\n" + raw[tm.end():]

    text = raw.strip()
    doc_id = sha1(url or file_name or text[:200])
    return Document(doc_id=doc_id, title=title, url=url, text=text, file_name=file_name)


# ------------------------------------------------------------------
# Loaders
# ------------------------------------------------------------------
def load_sample_corpus(limit: int = 0) -> List[Document]:
    docs: List[Document] = []
    meta_path = ASSET_SAMPLE_DIR / "_meta.json"
    order = None
    if meta_path.exists():
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        order = [m["file"] for m in meta]
    files = order or sorted(p.name for p in ASSET_SAMPLE_DIR.glob("*.txt"))
    if limit and limit > 0:
        files = files[:limit]
    for fname in files:
        p = ASSET_SAMPLE_DIR / fname
        if not p.exists():
            continue
        docs.append(parse_document(p.read_text(encoding="utf-8", errors="replace"), fname))
    log.info(f"[corpus] sample: {len(docs)} documents (assets/sample_corpus)")
    return docs


def load_dir_corpus(dir_path: str | Path, limit: int = 0) -> List[Document]:
    root = Path(dir_path)
    docs: List[Document] = []
    files = sorted([p for p in root.glob("*") if p.suffix.lower() in (".txt", ".md")])
    if limit and limit > 0:
        files = files[:limit]
    for p in files:
        docs.append(parse_document(p.read_text(encoding="utf-8", errors="replace"), p.name))
    log.info(f"[corpus] dir '{root}': {len(docs)} documents")
    return docs


def load_hf_corpus(dataset: str = "vuduylinh150804/vietmed-crawled-corpus",
                   limit: int = 300) -> List[Document]:
    """Tải corpus YouMed từ HuggingFace (nguồn chính thức trong bài báo).

    Dùng huggingface_hub (snapshot_download, chỉ file .txt, giới hạn limit file
    đầu tiên theo thứ tự alphabet - đủ ổn định cho demo; corpus đầy đủ 1932 docs).
    """
    try:
        from huggingface_hub import snapshot_download
    except ImportError as e:
        raise ImportError(
            "Cần cài huggingface_hub: pip install huggingface_hub"
        ) from e

    cache = ensure_dir(Path.home() / ".cache" / "adgr" / "hf" / dataset.replace("/", "__"))
    snapshot_download(repo_id=dataset, repo_type="dataset",
                      local_dir=str(cache), allow_patterns=["*.txt"])
    return load_dir_corpus(cache, limit=limit)


def load_corpus(source: str, hf_dataset: str, hf_limit: int,
                upload_dir: str = "uploads", limit: int = 0) -> List[Document]:
    if source == "sample":
        return load_sample_corpus(limit=limit)
    if source == "dir":
        if not Path(upload_dir).exists():
            log.warning(f"[corpus] upload_dir '{upload_dir}' khong ton tai -> dung sample")
            return load_sample_corpus(limit=limit)
        return load_dir_corpus(upload_dir, limit=limit)
    if source == "huggingface":
        return load_hf_corpus(hf_dataset, limit=hf_limit or 300)
    raise ValueError(f"Nguon corpus khong hop le: {source}")


# ------------------------------------------------------------------
# Persist
# ------------------------------------------------------------------
def save_documents(docs: List[Document], out_dir: Path) -> None:
    out_dir = ensure_dir(out_dir)
    write_docs = [d.__dict__ for d in docs]
    (out_dir / "documents.json").write_text(
        json.dumps(write_docs, ensure_ascii=False, indent=1), encoding="utf-8")


def load_documents(out_dir: Path) -> List[Document]:
    path = Path(out_dir) / "documents.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    return [Document(**d) for d in data]
