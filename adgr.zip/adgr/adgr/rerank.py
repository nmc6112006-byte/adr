"""Reranker backends (cross-encoder) - Eq.19 của paper.

- none  : bỏ rerank (dùng cosine như score tạm) — khớp ablation
          "w/o Cross-Encoder Reranking" của paper
- bge   : BAAI/bge-reranker-v2-m3 (nhẹ ~568M, hỗ trợ tốt tiếng Việt)
- qwen3 : Qwen/Qwen3-Reranker-0.6B — ĐÚNG model paper, dùng format
          instruct + logit token "no" làm điểm relevance
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List

import numpy as np

from .config import ADGRConfig, RerankConfig
from .utils import get_logger

log = get_logger("adgr.rerank")


class RerankerBackend(ABC):
    name = "base"

    @abstractmethod
    def score(self, query: str, docs: List[str]) -> np.ndarray:
        """Điểm relevance query-doc, mảng shape (len(docs),)."""
        raise NotImplementedError

    def close(self) -> None:
        pass


class NoReranker(RerankerBackend):
    name = "none"

    def score(self, query: str, docs: List[str]) -> np.ndarray:
        # pipeline sẽ không gọi backend này; giữ hàm an toàn
        return np.zeros(len(docs), dtype=np.float32)


# =====================================================================
# BGE cross-encoder
# =====================================================================
class BGEReranker(RerankerBackend):
    name = "bge"

    def __init__(self, cfg: RerankConfig):
        import torch
        from transformers import AutoModelForSequenceClassification, AutoTokenizer
        self.torch = torch
        self.cfg = cfg
        log.info(f"[rerank] Nạp {cfg.model} (device={cfg.device}) ...")
        self.tok = AutoTokenizer.from_pretrained(cfg.model)
        self.model = AutoModelForSequenceClassification.from_pretrained(
            cfg.model, torch_dtype=torch.float16 if cfg.device == "cuda" else torch.float32)
        self.model.to(cfg.device)
        self.model.eval()

    def score(self, query: str, docs: List[str]) -> np.ndarray:
        torch = self.torch
        out = np.zeros(len(docs), dtype=np.float32)
        bs = self.cfg.batch_size
        with torch.no_grad():
            for i in range(0, len(docs), bs):
                batch = docs[i:i + bs]
                pairs = [[query, d[:self.cfg.max_length * 4]] for d in batch]
                enc = self.tok(pairs, padding=True, truncation=True,
                               max_length=self.cfg.max_length, return_tensors="pt").to(self.cfg.device)
                logits = self.model(**enc).logits.squeeze(-1)
                out[i:i + len(batch)] = logits.float().cpu().numpy()
        return out


# =====================================================================
# Qwen3-Reranker (đúng paper)
# =====================================================================
_QWEN3_PREFIX = "<|im_start|>system\nJudge whether the Document meets the requirements based on the Query and the Instruct provided. Note that the answer can only be \"yes\" or \"no\".<|im_end|>\n<|im_start|>user\n"
_QWEN3_SUFFIX = "<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n"
_QWEN3_INSTR = ("Given a user query, retrieve relevant passages that answer the query "
                "(medical question answering in Vietnamese).")


class Qwen3Reranker(RerankerBackend):
    """Qwen3-Reranker-0.6B: causal LM dùng làm reranker qua logit token 'no'."""

    name = "qwen3"

    def __init__(self, cfg: RerankConfig, model_name: str = "Qwen/Qwen3-Reranker-0.6B"):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        self.torch = torch
        self.cfg = cfg
        log.info(f"[rerank] Nạp {model_name} (device={cfg.device}) ...")
        self.tok = AutoTokenizer.from_pretrained(model_name, padding_side="left")
        self.no_id = self.tok.convert_tokens_to_ids("no")
        self.model = AutoModelForCausalLM.from_pretrained(
            model_name, torch_dtype=torch.float16 if cfg.device == "cuda" else torch.float32)
        self.model.to(cfg.device)
        self.model.eval()

    def score(self, query: str, docs: List[str]) -> np.ndarray:
        torch = self.torch
        out = np.zeros(len(docs), dtype=np.float32)
        bs = self.cfg.batch_size
        with torch.no_grad():
            for i in range(0, len(docs), bs):
                batch_docs = docs[i:i + bs]
                texts = []
                for d in batch_docs:
                    d = d[: self.cfg.max_length * 3]
                    texts.append(
                        f"{_QWEN3_PREFIX}<Instruct>: {_QWEN3_INSTR}\n"
                        f"<Query>: {query}\n<Document>: {d}{_QWEN3_SUFFIX}")
                enc = self.tok(texts, padding=True, truncation=True,
                               max_length=self.cfg.max_length, return_tensors="pt").to(self.cfg.device)
                logits = self.model(**enc).logits[:, -1, :]
                no_logit = logits[:, self.no_id]
                out[i:i + len(batch_docs)] = no_logit.float().cpu().numpy()
        return out

    def close(self) -> None:
        try:
            del self.model
            import torch
            torch.cuda.empty_cache()
        except Exception:
            pass


def make_reranker(cfg: ADGRConfig) -> RerankerBackend:
    kind = cfg.rerank_backend
    if kind == "none":
        return NoReranker()
    if kind == "bge":
        return BGEReranker(cfg.rerank)
    if kind == "qwen3":
        return Qwen3Reranker(cfg.rerank)
    raise ValueError(f"rerank_backend không hợp lệ: {kind}")
