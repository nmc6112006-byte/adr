"""LLM-as-Judge 4 chiều — prompt nguyên văn theo supplementary của paper.

Comprehensiveness / Diversity / Empowerment / Directness, điểm 0..1,
không thiên vị câu trả lời dài.
"""
from __future__ import annotations

import json
from typing import Dict

from .llm import LLMBackend
from .utils import get_logger

log = get_logger("adgr.judge")

JUDGE_SYSTEM = """You are an experienced medical expert and evaluator with strong clinical knowledge and the ability to assess medical responses objectively, fairly, and consistently.

You will be provided with:
- Question: the medical question,
- Answer: the generated answer to evaluate,
- Reference: the reference answer used for comparison.

Your task is to carefully evaluate the generated answer against both the Question and the Reference answer.

Each answer must be scored independently on a continuous scale from 0 to 1 according to the following criteria:
- Comprehensiveness: the extent to which the answer includes the essential medical information required to fully address the question, especially the key points covered by the reference answer.
- Diversity: the extent to which the answer captures a broad range of relevant aspects, such as conditions, exceptions, contextual factors, or additional considerations that are useful for understanding the question.
- Empowerment: the extent to which the answer supports the reader in understanding the medical issue and making informed judgments, for example by explaining implications, risks, severity, warnings, recommendations, or appropriate next steps.
- Directness: the extent to which the answer is clear, specific, and focused on the question, while avoiding unnecessary, redundant, or unrelated information.

For each criterion, assign a score between 0 and 1 based on your expert judgment. The score is not restricted to predefined discrete values. Higher scores indicate better alignment with the Question and the Reference answer.

Evaluation principles:
- Carefully compare the generated answer with both the Question and the Reference answer before assigning scores.
- Do not favor longer answers by default.
- Long but unfocused, redundant, or irrelevant answers should receive lower Directness scores.
- Do not penalize an answer merely for using different wording from the Reference if the medical meaning is preserved.
- Do not introduce external medical knowledge when judging completeness, unless the answer contains clear medical errors, unsafe advice, or potentially harmful misinformation.

Return ONLY JSON:
{"comprehensiveness": <0..1>, "diversity": <0..1>, "empowerment": <0..1>, "directness": <0..1>, "overall": <mean of the four>}"""


def judge_answer(llm: LLMBackend, question: str, answer: str, reference: str) -> Dict[str, float]:
    usr = f"Question: {question}\n\nAnswer: {answer[:2500]}\n\nReference: {reference[:2000]}\n\nJSON:"
    try:
        raw = llm.chat([{"role": "system", "content": JUDGE_SYSTEM},
                        {"role": "user", "content": usr}],
                       temperature=0.0, max_tokens=512, json_mode=True)
        s, e = raw.find("{"), raw.rfind("}")
        data = json.loads(raw[s:e + 1])
        out = {}
        for k in ("comprehensiveness", "diversity", "empowerment", "directness"):
            out[k] = float(data.get(k, 0.0))
        vals = [out[k] for k in out]
        out["overall"] = sum(vals) / len(vals) if vals else 0.0
        return out
    except Exception as e:
        log.warning(f"judge_answer lỗi: {e}")
        return {"comprehensiveness": 0.0, "diversity": 0.0,
                "empowerment": 0.0, "directness": 0.0, "overall": 0.0}
