"""Tokenize tiếng Việt cho BM25.

Ưu tiên: underthesea.word_tokenize (chuẩn NLP tiếng Việt) -> pyvi ->
fallback regex đơn giản. Fallback luôn hoạt động để pipeline không bao giờ
gãy vì thiếu dependency.
"""
from __future__ import annotations

import re
from functools import lru_cache

try:  # optional dependency
    from underthesea import word_tokenize as _ut_word_tokenize
    _HAVE_UT = True
except Exception:  # pragma: no cover
    _HAVE_UT = False

_TOKEN_RE = re.compile(r"[a-zàáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđ]+", re.IGNORECASE)

# Stopword tiếng Việt gọn (đủ dùng cho BM25/keyword heuristic)
VI_STOPWORDS = {
    "và", "hoặc", "của", "các", "những", "cho", "với", "trong", "ngoài", "trên",
    "dưới", "là", "được", "có", "không", "nên", "cần", "phải", "khi", "thì", "mà",
    "này", "đó", "nó", "họ", "ta", "tôi", "bạn", "một", "hai", "ba", "nhiều",
    "ít", "rất", "quá", "cũng", "đều", "đã", "sẽ", "đang", "vẫn", "về", "từ",
    "theo", "như", "bởi", "do", "vì", "nếu", "để", "thành", "ra", "đi", "lại",
    "thường", "có_thể", "có thể", "gì", "ai", "nào", "sao", "bao_nhiêu",
    "liệu", "hay", "hoặc", "nhưng", "tuy_nhiên", "vì_vậy", "do_đó", "tuy",
    "the", "of", "and", "in", "is", "are", "for", "to", "a", "an",
}


@lru_cache(maxsize=1)
def _backend() -> str:
    if _HAVE_UT:
        return "underthesea"
    try:
        from pyvi import ViTokenizer  # noqa: F401
        return "pyvi"
    except Exception:
        return "regex"


def tokenize(text: str, lowercase: bool = True, drop_stopwords: bool = False) -> list[str]:
    """Tokenize văn bản tiếng Việt thành list token.

    underthesea trả về token dạng "dòng_điện" (underscore thay space).
    """
    if not text:
        return []
    text = text.replace("<|#|>", " ")
    backend = _backend()
    try:
        if backend == "underthesea":
            toks = _ut_word_tokenize(str(text), format="text").split()
        elif backend == "pyvi":
            from pyvi import ViTokenizer
            toks = ViTokenizer.tokenize(str(text)).split()
        else:
            toks = _TOKEN_RE.findall(str(text))
    except Exception:
        toks = _TOKEN_RE.findall(str(text))

    out = []
    for tok in toks:
        tok = tok.strip()
        if not tok:
            continue
        if lowercase:
            tok = tok.lower()
        # tách token ghép "dòng_điện" thành ["dòng_điện"] - giữ nguyên cho BM25
        if drop_stopwords and tok in VI_STOPWORDS:
            continue
        if drop_stopwords and "_" in tok and tok.replace("_", " ") in VI_STOPWORDS:
            continue
        if len(tok) == 1 and tok not in ("đ", "h"):
            continue
        out.append(tok)
    return out


def keywords_heuristic(text: str, max_kw: int = 8) -> list[str]:
    """Heuristic trích keyword (dùng cho MockLLM): token dài >=3 ký tự,
    bỏ stopword, ưu tiên token chứa dấu tiếng Việt hoặc ghép underscore."""
    toks = tokenize(text, lowercase=True, drop_stopwords=True)
    scored = []
    seen = set()
    for t in toks:
        if len(t) < 3 or t in seen:
            continue
        seen.add(t)
        score = 0.0
        if "_" in t:
            score += 2.0
        if any(ch in t for ch in "ăâđêôơưáàảãạếềểễệíìỉĩịóòỏõọúùủũụýỳỷỹỵ"):
            score += 1.5
        score += min(len(t), 12) / 12.0
        scored.append((score, t))
    scored.sort(reverse=True)
    return [t for _, t in scored[:max_kw]]
