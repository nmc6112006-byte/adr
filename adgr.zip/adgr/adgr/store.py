"""AdgrStore: đóng gói corpus + chunks + KG + toàn bộ index, persist/restore.

Cấu trúc data_dir:
  data/
    documents.json        # corpus
    chunks.json           # retrieval chunks (T)
    kg/entities.json      # đồ thị tri thức
    kg/relations.json
    index/
      bm25_entity.pkl     # BM25 trên entity name + description
      bm25_chunk.pkl      # BM25 trên chunk (dùng cho mock anchor khi cần)
      vec_entity.npz/json # dense index trên entity NAME (Eq.4)
      vec_relation.npz    # dense index trên edge text (Eq.9/14)
      vec_chunk.npz       # dense index trên chunk (Eq.15)
    meta.json             # cấu hình lúc build
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from .corpus import Chunk, Document, load_documents
from .index_bm25 import BM25Index
from .index_vec import NumpyVectorIndex
from .kg_graph import KnowledgeGraph
from .utils import write_json, read_json, ensure_dir


class AdgrStore:
    def __init__(self, data_dir: str | Path):
        self.data_dir = ensure_dir(data_dir)
        self.documents: List[Document] = []
        self.chunks: List[Chunk] = []
        self.chunk_by_id: Dict[str, Chunk] = {}
        self.kg = KnowledgeGraph()
        self.bm25_entity = BM25Index()
        self.bm25_chunk = BM25Index()
        self.vec_entity: Optional[NumpyVectorIndex] = None
        self.vec_relation: Optional[NumpyVectorIndex] = None
        self.vec_chunk: Optional[NumpyVectorIndex] = None
        self.meta: dict = {}

    # ---------------- paths ----------------
    @property
    def index_dir(self) -> Path:
        return self.data_dir / "index"

    @property
    def kg_dir(self) -> Path:
        return self.data_dir / "kg"

    # ---------------- save/load ----------------
    def save_corpus(self) -> None:
        write_json([d.__dict__ for d in self.documents], self.data_dir / "documents.json")
        write_json([c.to_dict() for c in self.chunks], self.data_dir / "chunks.json")

    def save_meta(self) -> None:
        write_json(self.meta, self.data_dir / "meta.json")

    def save_all(self) -> None:
        self.save_corpus()
        self.kg.save(self.kg_dir)
        ensure_dir(self.index_dir)
        self.bm25_entity.save(self.index_dir / "bm25_entity.pkl")
        self.bm25_chunk.save(self.index_dir / "bm25_chunk.pkl")
        for name, vec in [("vec_entity", self.vec_entity), ("vec_relation", self.vec_relation),
                          ("vec_chunk", self.vec_chunk)]:
            if vec is not None:
                vec.save(self.index_dir / f"{name}.npz")
        self.save_meta()

    def load_corpus(self) -> "AdgrStore":
        self.documents = load_documents(self.data_dir)
        self.chunks = [Chunk(**c) for c in read_json(self.data_dir / "chunks.json")]
        self.chunk_by_id = {c.chunk_id: c for c in self.chunks}
        return self

    def load_kg(self) -> "AdgrStore":
        self.kg = KnowledgeGraph.load(self.kg_dir)
        return self

    def load_index(self) -> "AdgrStore":
        self.bm25_entity = BM25Index.load(self.index_dir / "bm25_entity.pkl")
        self.bm25_chunk = BM25Index.load(self.index_dir / "bm25_chunk.pkl")
        self.vec_entity = NumpyVectorIndex.load(self.index_dir / "vec_entity.npz")
        self.vec_relation = NumpyVectorIndex.load(self.index_dir / "vec_relation.npz")
        self.vec_chunk = NumpyVectorIndex.load(self.index_dir / "vec_chunk.npz")
        meta_path = self.data_dir / "meta.json"
        if meta_path.exists():
            self.meta = read_json(meta_path)
        return self

    def is_index_ready(self) -> bool:
        return (self.index_dir / "vec_chunk.npz").exists()
