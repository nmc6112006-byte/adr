"""Generation (Block 6): a = M(q, C(q)) — sinh câu trả lời từ context."""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List

from .config import ADGRConfig
from .corpus import Chunk
from .llm import LLMBackend
from .utils import estimate_tokens


@dataclass
class GenerationResult:
    answer: str
    prompt_tokens_est: int
    output_tokens_est: int
    n_context_chunks: int
    context_chars: int


GEN_USER_TMPL = """NGỮ CẢNH:
{context}

CÂU HỎI: {question}

Trả lời (tiếng Việt, dựa trên ngữ cảnh trên):"""


def build_context(chunks: List[Chunk]) -> str:
    """Ghép context cuối cùng C(q) — có nhãn nguồn để truy vết bằng chứng."""
    parts = []
    for i, ch in enumerate(chunks, 1):
        parts.append(f"[Nguồn {i}] {ch.doc_title}"
                     + (f" ({ch.source_url})" if ch.source_url else "")
                     + "\n" + ch.content)
    return "\n\n".join(parts)


def generate_answer(llm: LLMBackend, cfg: ADGRConfig, query: str,
                    chunks: List[Chunk]) -> GenerationResult:
    context = build_context(chunks)
    prompt = GEN_USER_TMPL.format(context=context, question=query)
    prompt_tokens = estimate_tokens(
        cfg.generation.system_prompt + prompt)
    answer = llm.chat(
        [{"role": "system", "content": cfg.generation.system_prompt},
         {"role": "user", "content": prompt}],
        temperature=cfg.generation.temperature,
        max_tokens=cfg.generation.max_tokens)
    return GenerationResult(
        answer=answer.strip(),
        prompt_tokens_est=prompt_tokens,
        output_tokens_est=estimate_tokens(answer),
        n_context_chunks=len(chunks),
        context_chars=len(context))
