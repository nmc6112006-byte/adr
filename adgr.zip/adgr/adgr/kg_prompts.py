"""Prompts cho ADGR.

1) Extraction prompt - tái tạo theo supplementary của paper: định dạng
   delimiter <|#|>, schema 11 loại thực thể, temperature=0.
2) Keyword prompt - Block 2: low-level (terminology/tên riêng) và
   high-level (khái niệm rộng / ý định truy vấn).
"""
from __future__ import annotations

from typing import List

EXTRACTION_SYSTEM = """---Role---
You are a Knowledge Graph Specialist responsible for extracting entities and relationships from the input text (Vietnamese medical content).

---Instructions---
1. Entity Extraction & Output:
- Identification:
  Identify clearly defined and meaningful entities in the input text.
- Entity Details:
  For each identified entity, extract:
    entity_name: The name of the entity (keep the original Vietnamese form).
    entity_type: Categorize the entity using one of the following types: {entity_types}. If none apply, classify it as Other.
    entity_description: Provide a concise yet comprehensive description of the entity's attributes, grounded in the input text only.
- Output Format:
  Output 4 fields for each entity on a single line, delimited by <|#|>.
  Format:
  entity<|#|>entity_name<|#|>entity_type<|#|>entity_description

2. Relationship Extraction & Output:
- Identification:
  Identify direct, clearly stated relationships between previously extracted entities.
- Relationship Details:
  For each binary relationship, extract:
    source_entity: The name of the source entity.
    target_entity: The name of the target entity.
    relationship_keywords: High-level keywords summarizing the relationship (e.g. "điều trị", "chống chỉ định với", "gây ra", "triệu chứng của").
    relationship_description: A concise explanation of the relationship grounded in the input text.
- Output Format:
  Output 5 fields for each relationship on a single line, delimited by <|#|>.
  Format:
  relation<|#|>source_entity<|#|>target_entity<|#|>relationship_keywords<|#|>relationship_description

3. Constraints:
- Only extract information supported by the input text; do not hallucinate entities or relations.
- Do not extract headings, navigation, advertisements or boilerplate.
- Prefer high-quality entities: diseases, symptoms, drugs/active ingredients, chemicals, proteins, anatomy, biological processes, exposures, diagnostic tests, treatment methods.

4. Completion Signal:
Output the literal string <|COMPLETE|> only after all entities and relationships have been completely extracted and outputted.
"""

EXTRACTION_USER_TMPL = """VĂN BẢN:
{text}

(Hãy trích xuất entities và relations theo đúng định dạng, kết thúc bằng <|COMPLETE|>)"""

KEYWORD_SYSTEM = """Bạn là một module trích xuất keyword cho hệ thống GraphRAG y tế.
Trích xuất keyword từ câu hỏi, trả về CHỈ JSON hợp lệ:
{"low_level": [...], "high_level": [...]}

- low_level: 3-6 keyword GIỮ ĐÚNG terminology/tên riêng xuất hiện trong câu hỏi
  (tên thuốc, hoạt chất, tên bệnh, triệu chứng, xét nghiệm...).
- high_level: 2-4 keyword KHÁI NIỆM RỘNG mô tả ý định/chủ đề truy vấn
  (vd: "chống chỉ định", "công dụng", "tác dụng phụ", "cách điều trị")."""

KEYWORD_USER_TMPL = """CÂU HỎI: {question}

JSON:"""
