"""BM25 index (rank-bm25) cho entity (name + description) và chunk.

Đúng Bảng 2: "Anchor embedding: Entity name (dense); name and description (BM25)".
"""
from __future__ import annotations

import json
import pickle
from pathlib import Path
from typing import Dict, List, Tuple

from rank_bm25 import BM25Okapi

from .utils import ensure_dir
from .vitoken import tokenize


class BM25Index:
    """BM25 trên corpus token hoá sẵn. Kết quả trả (key, score)."""

    def __init__(self):
        self.keys: List[str] = []
        self._bm25: BM25Okapi | None = None

    def build(self, keys: List[str], corpus_texts: List[str]) -> None:
        self.keys = list(keys)
        tokenized = [tokenize(t, lowercase=True, drop_stopwords=True) for t in corpus_texts]
        self._bm25 = BM25Okapi(tokenized) if tokenized else None

    def search(self, query: str, top_k: int = 10) -> List[Tuple[str, float]]:
        if self._bm25 is None or not self.keys:
            return []
        scores = self._bm25.get_scores(tokenize(query, lowercase=True, drop_stopwords=True))
        order = sorted(range(len(scores)), key=lambda i: -scores[i])[:top_k]
        # bỏ item có điểm 0 tuyệt đối (không match)
        return [(self.keys[i], float(scores[i])) for i in order if scores[i] > 0]

    def save(self, path: str | Path) -> None:
        path = Path(path)
        ensure_dir(path.parent)
        with open(path, "wb") as f:
            pickle.dump({"keys": self.keys, "bm25": self._bm25}, f)

    @classmethod
    def load(cls, path: str | Path) -> "BM25Index":
        with open(path, "rb") as f:
            data = pickle.load(f)
        idx = cls()
        idx.keys = data["keys"]
        idx._bm25 = data["bm25"]
        return idx
