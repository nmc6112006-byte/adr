#!/usr/bin/env python3
"""ADGR - Script chạy pipeline đầy đủ MỘT LẦN trên Kaggle.

Cách dùng trên Kaggle (GPU T4 x2 / P100):
  1. Tạo Notebook, bật Internet (Settings -> Internet -> ON)
  2. Upload repo adgr/ (hoặc git clone)
  3. Cell 1: !pip install -r requirements.txt sentence-transformers
  4. Cell 2: !python scripts/run_kaggle.py --data-dir /kaggle/working/data

Các chế độ LLM:
  --llm vllm_local   : dùng vLLM in-process với Qwen2.5-14B-Instruct-AWQ (đúng paper,
                       cần GPU >= 16GB, lần đầu tải ~10GB weights)
  --llm openai_compat: trỏ tới endpoint OpenAI-compatible (vd Ollama/vLLM serve/OpenRouter)
                       --base-url http://... --model ... --api-key ...
  --llm mock         : không cần GPU/API - kiểm tra toàn pipeline nhanh (mặc định)

Embedding thật:  --embed st_local --embed-model intfloat/multilingual-e5-small
Reranker thật:   --rerank bge  (BAAI/bge-reranker-v2-m3)  hoặc  --rerank qwen3
"""
from __future__ import annotations

import argparse
import gc
import sys
import time
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default=str(ROOT / "data"))
    ap.add_argument("--llm", default="mock", choices=["mock", "openai_compat", "vllm_local", "zai"])
    ap.add_argument("--llm-model", default="Qwen/Qwen2.5-14B-Instruct-AWQ")
    ap.add_argument("--base-url", default="http://localhost:8000/v1")
    ap.add_argument("--api-key", default="EMPTY")
    ap.add_argument("--embed", default="hash_mock", choices=["hash_mock", "st_local"])
    ap.add_argument("--embed-model", default="intfloat/multilingual-e5-small")
    ap.add_argument("--embed-device", default="cpu")
    ap.add_argument("--rerank", default="none", choices=["none", "bge", "qwen3"])
    ap.add_argument("--rerank-device", default="cpu")
    ap.add_argument("--source", default="sample", choices=["sample", "huggingface", "dir"])
    ap.add_argument("--hf-limit", type=int, default=300)
    ap.add_argument("--max-chunks-kg", type=int, default=0,
                    help="giới hạn số chunk trích xuất KG (0 = tất cả)")
    ap.add_argument("--eval-limit", type=int, default=16)
    ap.add_argument("--ablation", action="store_true")
    ap.add_argument("--skip-eval", action="store_true")
    args = ap.parse_args()

    data_dir = Path(args.data_dir)
    data_dir.mkdir(parents=True, exist_ok=True)

    from adgr.config import ADGRConfig
    from adgr.utils import set_seed, get_logger
    log = get_logger("adgr.kaggle")
    set_seed(13)

    cfg = ADGRConfig.load(ROOT / "configs" / "default.yaml", overrides={
        "llm_backend": args.llm,
        "embed_backend": args.embed,
        "rerank_backend": args.rerank,
        "corpus.source": args.source,
        "corpus.hf_limit": args.hf_limit,
        "kg.max_chunks_per_run": args.max_chunks_kg,
        "embed.model": args.embed_model,
        "embed.device": args.embed_device,
        "rerank.device": args.rerank_device,
        "llm.model": args.llm_model,
        "llm.base_url": args.base_url,
        "llm.api_key": args.api_key,
    })

    # ================= [1/5] Corpus + chunking =================
    t0 = time.time()
    from adgr.build_index import build_corpus_stage
    build_corpus_stage(cfg, data_dir)
    log.info(f"[1/5] corpus xong trong {time.time()-t0:.0f}s")

    # ================= [2/5] KG extraction (LLM) =================
    t0 = time.time()
    from adgr.build_index import build_kg_stage
    build_kg_stage(cfg, data_dir)
    log.info(f"[2/5] KG xong trong {time.time()-t0:.0f}s")

    # ================= [3/5] Giải phóng LLM (nếu vLLM) =================
    if args.llm == "vllm_local":
        try:
            from adgr.llm import VllmLocalLLM
            # LLM đã được close trong build_kg_stage; giải phóng thêm bộ nhớ
            import torch
            gc.collect()
            torch.cuda.empty_cache()
            log.info("[3/5] Đã giải phóng vLLM khỏi GPU")
        except Exception:
            pass

    # ================= [4/5] Indices (embed + BM25) =================
    t0 = time.time()
    from adgr.build_index import build_index_stage
    build_index_stage(cfg, data_dir)
    log.info(f"[4/5] indices xong trong {time.time()-t0:.0f}s")

    # ================= [5/5] Demo query + eval + viz =================
    from adgr.store import AdgrStore
    from adgr.embeddings import make_embedder
    from adgr.llm import make_llm
    from adgr.rerank import make_reranker
    from adgr.retrieval import ADGRRetriever
    from adgr.generation import generate_answer

    store = AdgrStore(data_dir).load_corpus().load_kg().load_index()
    llm = make_llm(cfg)
    embedder = make_embedder(cfg)
    reranker = make_reranker(cfg)
    retriever = ADGRRetriever(store, cfg, llm, embedder, reranker)

    out_dir = data_dir / "outputs"
    out_dir.mkdir(parents=True, exist_ok=True)

    demo_queries = [
        "A.t Vildagliptin dùng để điều trị bệnh gì?",
        "Hội chứng Tourette có các triệu chứng gì?",
        "Adrenalin (epinephrin) có tác dụng gì trong hồi sức cấp cứu?",
        "Tăng acid uric trong máu dẫn đến những bệnh lý nào?",
    ]
    log.info("[5/5] DEMO QUERIES")
    for q in demo_queries:
        t0 = time.time()
        chunks, trace = retriever.retrieve(q)
        gen = generate_answer(llm, cfg, q, chunks)
        log.info(f"\nQ: {q}\n"
                 f"  anchors={len(trace.anchors)} edges={len(trace.edges)} "
                 f"final={len(trace.final_chunks)} ({trace.timings['total_ms']:.0f} ms)\n"
                 f"  A: {gen.answer[:220]}...")
        safe = "q" + str(abs(hash(q)) % 1000)
        from adgr.viz import export_trace_html
        export_trace_html(store, trace, out_dir / f"trace_{safe}.html")

    # eval + ablation
    if not args.skip_eval:
        from adgr.eval_runner import run_eval
        run_eval(store, cfg, retriever, embedder,
                 out_path=out_dir / "eval_results.json",
                 eval_limit=args.eval_limit,
                 with_ablation=args.ablation,
                 judge=(args.llm != "mock"))

    # KG viz
    from adgr.viz import export_kg_html
    kg_html = export_kg_html(store, out_dir / "kg.html", top_n=400)
    log.info(f"Đã xuất đồ thị KG: {kg_html}")

    # stats
    st = store.kg.stats()
    log.info(f"FINAL STATS: docs={len(store.documents)} chunks={len(store.chunks)} "
             f"entities={st['num_entities']} relations={st['num_relations']} "
             f"DSER={st['dser_pct']}% LCR={st['lcr_pct']}%")
    log.info(f"Toàn bộ artifacts nằm trong: {data_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
