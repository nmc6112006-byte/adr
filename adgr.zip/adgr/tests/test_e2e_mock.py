#!/usr/bin/env python3
"""Test end-to-end toàn pipeline ADGR với mock backends (không cần GPU/API).

Chạy: python tests/test_e2e_mock.py
"""
import sys
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

import shutil


def run():
    data_dir = ROOT / "data_test"
    if data_dir.exists():
        shutil.rmtree(data_dir)

    from adgr.config import ADGRConfig
    from adgr.utils import set_seed

    set_seed(13)
    cfg = ADGRConfig.load(ROOT / "configs" / "default.yaml", overrides={
        "llm_backend": "mock", "embed_backend": "hash_mock", "rerank_backend": "none",
        "corpus.source": "sample",
    })

    from adgr.build_index import build_corpus_stage, build_kg_stage, build_index_stage

    print("\n########## STAGE 1: CORPUS ##########")
    chunks = build_corpus_stage(cfg, data_dir)
    assert len(chunks) > 50, f"chunk quá ít: {len(chunks)}"

    print("\n########## STAGE 2: KG ##########")
    kg = build_kg_stage(cfg, data_dir)
    assert len(kg.entities) > 20, f"entities quá ít: {len(kg.entities)}"
    assert len(kg.relations) > 10, f"relations quá ít: {len(kg.relations)}"
    stats = kg.stats()
    print("KG stats:", stats)

    print("\n########## STAGE 3: INDEX ##########")
    build_index_stage(cfg, data_dir)

    from adgr.store import AdgrStore
    from adgr.embeddings import make_embedder
    from adgr.llm import make_llm
    from adgr.rerank import make_reranker
    from adgr.retrieval import ADGRRetriever
    from adgr.generation import generate_answer

    store = AdgrStore(data_dir).load_corpus().load_kg().load_index()
    llm = make_llm(cfg)
    embedder = make_embedder(cfg)
    reranker = make_reranker(cfg)
    retriever = ADGRRetriever(store, cfg, llm, embedder, reranker)

    print("\n########## STAGE 4: RETRIEVAL + GENERATION ##########")
    queries = [
        "A.t Vildagliptin dùng để điều trị bệnh gì?",
        "Hội chứng Tourette có triệu chứng gì?",
        "Acyclovir Boston 200 điều trị những bệnh gì?",
    ]
    for q in queries:
        chunks_out, trace = retriever.retrieve(q)
        assert chunks_out, f"không retrieve được chunk cho: {q}"
        gen = generate_answer(llm, cfg, q, chunks_out)
        assert gen.answer, "answer trống"
        print(f"\nQ: {q}")
        print(f"   Kl={trace.keywords.low_level[:4]} Kh={trace.keywords.high_level[:2]}")
        print(f"   anchors={len(trace.anchors)} edges={len(trace.edges)} "
              f"merged={len(trace.merged)} final={len(trace.final_chunks)}")
        print(f"   top1: {chunks_out[0].doc_title[:60]} | {chunks_out[0].section_path[:2]}")
        print(f"   answer: {gen.answer[:140]}...")

    print("\n########## STAGE 5: ABLATION MODES ##########")
    for mode in ["dense_only", "no_anchor", "no_edge_filter", "no_rerank"]:
        chunks_out, trace = retriever.retrieve(queries[0], mode=mode)
        print(f"   {mode:<18} final={len(trace.final_chunks)}")

    print("\n########## STAGE 6: EVAL (limit 6, no judge) ##########")
    from adgr.eval_runner import run_eval
    results = run_eval(store, cfg, retriever, embedder,
                       out_path=data_dir / "eval_results.json",
                       eval_limit=6, with_ablation=False, judge=False)
    full = results["modes"]["full"]
    assert full["retrieval"]["Hit@3"] >= 0.0
    print("OK eval:", full["retrieval"])

    print("\n########## STAGE 7: VIZ ##########")
    from adgr.viz import export_kg_html, export_trace_html
    kg_html = export_kg_html(store, data_dir / "outputs" / "kg.html", top_n=300)
    q = queries[0]
    chunks_out, trace = retriever.retrieve(q)
    tr_html = export_trace_html(store, trace, data_dir / "outputs" / "trace.html")
    assert kg_html.exists() and tr_html.exists()
    print(f"viz ok: {kg_html.name} ({kg_html.stat().st_size//1024} KB), "
          f"{tr_html.name} ({tr_html.stat().st_size//1024} KB)")

    print("\n================ ALL E2E TESTS PASSED ================")
    print(f"Data dir: {data_dir}")


if __name__ == "__main__":
    run()
